import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { file, fileName, metadata } = await req.json();
    
    const pinataApiKey = Deno.env.get('PINATA_API_KEY');
    const pinataSecret = Deno.env.get('PINATA_SECRET');

    if (!pinataApiKey || !pinataSecret) {
      console.error('Missing Pinata credentials');
      return new Response(
        JSON.stringify({ error: 'Missing Pinata API credentials' }), 
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Convert base64 file to blob
    const fileBuffer = Uint8Array.from(atob(file), c => c.charCodeAt(0));
    
    // Create form data for Pinata API
    const formData = new FormData();
    formData.append('file', new Blob([fileBuffer]), fileName);
    
    // Add metadata if provided
    if (metadata) {
      formData.append('pinataMetadata', JSON.stringify({
        name: fileName,
        keyvalues: metadata
      }));
    }

    console.log('Uploading file to Pinata:', fileName);

    // Upload to Pinata
    const pinataResponse = await fetch('https://api.pinata.cloud/pinning/pinFileToIPFS', {
      method: 'POST',
      headers: {
        'pinata_api_key': pinataApiKey,
        'pinata_secret_api_key': pinataSecret,
      },
      body: formData,
    });

    if (!pinataResponse.ok) {
      const errorText = await pinataResponse.text();
      console.error('Pinata API error:', errorText);
      return new Response(
        JSON.stringify({ error: 'Failed to upload to IPFS' }), 
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const pinataResult = await pinataResponse.json();
    console.log('Upload successful:', pinataResult);

    return new Response(
      JSON.stringify({
        success: true,
        ipfsHash: pinataResult.IpfsHash,
        pinSize: pinataResult.PinSize,
        timestamp: pinataResult.Timestamp,
        isDuplicate: pinataResult.isDuplicate || false
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error in upload-to-pinata function:', error);
    return new Response(
      JSON.stringify({ error: error.message }), 
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});