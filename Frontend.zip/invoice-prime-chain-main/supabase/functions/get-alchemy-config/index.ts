import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Checking Alchemy environment variables...');
    const alchemyApiKey = Deno.env.get('ALCHEMY_API_KEY');
    const alchemyAppId = Deno.env.get('ALCHEMY_APP_ID');
    
    console.log('ALCHEMY_API_KEY present:', !!alchemyApiKey);
    console.log('ALCHEMY_APP_ID present:', !!alchemyAppId);
    
    if (!alchemyApiKey) {
      console.error('Missing ALCHEMY_API_KEY');
      return new Response(
        JSON.stringify({ error: 'ALCHEMY_API_KEY not configured' }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }
    
    if (!alchemyAppId) {
      console.error('Missing ALCHEMY_APP_ID');
      return new Response(
        JSON.stringify({ error: 'ALCHEMY_APP_ID not configured' }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }
    
    console.log('Both Alchemy credentials found, returning configuration');

    return new Response(
      JSON.stringify({
        rpcUrl: `https://eth-sepolia.g.alchemy.com/v2/${alchemyApiKey}`,
        appId: alchemyAppId
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  } catch (error) {
    console.error('Error getting Alchemy config:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});