import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { walletService, type WalletStatus } from '@/services/walletService';

interface WalletState {
  isConnected: boolean;
  address: string | null;
  isLoading: boolean;
  error: string | null;
}

interface WalletContextValue extends WalletState {
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  shortenAddress: (address: string) => string;
}

const WalletContext = createContext<WalletContextValue | undefined>(undefined);

export const WalletProvider = ({ children }: { children: ReactNode }) => {
  const [walletState, setWalletState] = useState<WalletState>({
    isConnected: false,
    address: null,
    isLoading: false,
    error: null,
  });

  // Update state from wallet status
  const updateStateFromStatus = useCallback((status: WalletStatus) => {
    setWalletState({
      isConnected: status.isConnected,
      address: status.address,
      isLoading: false,
      error: status.error,
    });
  }, []);

  // Check connection on mount
  useEffect(() => {
    walletService.checkConnection().then(updateStateFromStatus);
  }, [updateStateFromStatus]);

  // Subscribe to wallet status changes
  useEffect(() => {
    const unsubscribe = walletService.subscribe(updateStateFromStatus);
    return unsubscribe;
  }, [updateStateFromStatus]);

  // Set up account change listener
  useEffect(() => {
    walletService.setupAccountsListener((accounts: string[]) => {
      if (walletService.getDisconnectFlag()) {
        return;
      }
      
      if (accounts.length === 0) {
        disconnectWallet();
      } else {
        setWalletState({
          isConnected: true,
          address: accounts[0],
          isLoading: false,
          error: null,
        });
      }
    });

    return () => {
      walletService.removeListeners();
    };
  }, []);

  // Set up chain change listener
  useEffect(() => {
    walletService.setupChainListener(() => {
      window.location.reload();
    });

    return () => {
      walletService.removeListeners();
    };
  }, []);

  const connectWallet = async () => {
    setWalletState(prev => ({ ...prev, isLoading: true, error: null }));
    await walletService.connect();
  };

  const disconnectWallet = () => {
    walletService.disconnect();
  };

  const shortenAddress = (address: string): string => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <WalletContext.Provider
      value={{
        ...walletState,
        connectWallet,
        disconnectWallet,
        shortenAddress,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};
