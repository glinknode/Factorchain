import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import InvoiceCacheService from '@/services/invoiceCacheService';
import type { CompanyInvoice, InvestorInvoice, MarketInvoice } from '@/lib/blockchain';
import { useWallet } from '@/hooks/useWallet';

interface InvoiceCacheContextType {
  companyInvoices: CompanyInvoice[];
  investorInvoices: InvestorInvoice[];
  marketInvoices: MarketInvoice[];
  isLoading: boolean;
  refresh: () => Promise<void>;
  invalidateAndRefresh: () => Promise<void>;
}

const InvoiceCacheContext = createContext<InvoiceCacheContextType | null>(null);

export function InvoiceCacheProvider({ children }: { children: ReactNode }) {
  const [companyInvoices, setCompanyInvoices] = useState<CompanyInvoice[]>([]);
  const [investorInvoices, setInvestorInvoices] = useState<InvestorInvoice[]>([]);
  const [marketInvoices, setMarketInvoices] = useState<MarketInvoice[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { address } = useWallet();
  const isUpdatingRef = useRef(false);
  const lastAddressRef = useRef<string | null>(null);

  // Subscribe to cache updates with debouncing
  useEffect(() => {
    let debounceTimer: NodeJS.Timeout;
    
    const handleCacheUpdate = () => {
      if (isUpdatingRef.current) return;
      
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        // Market invoices available to everyone (optionally filtered by wallet)
        const market = InvoiceCacheService.getMarketInvoices(address || undefined);
        setMarketInvoices(prev => 
          JSON.stringify(prev) !== JSON.stringify(market) ? market : prev
        );
        
        // Company and investor invoices only available with wallet
        if (address) {
          const company = InvoiceCacheService.getCompanyInvoices(address);
          const investor = InvoiceCacheService.getInvestorInvoices(address);
          
          setCompanyInvoices(prev => 
            JSON.stringify(prev) !== JSON.stringify(company) ? company : prev
          );
          setInvestorInvoices(prev => 
            JSON.stringify(prev) !== JSON.stringify(investor) ? investor : prev
          );
        }
        
        setIsLoading(InvoiceCacheService.getIsFetching());
      }, 100); // 100ms debounce
    };

    const unsubscribe = InvoiceCacheService.subscribe(handleCacheUpdate);
    
    return () => {
      clearTimeout(debounceTimer);
      unsubscribe();
    };
  }, [address]);

  // Load all invoices on mount (without wallet requirement)
  useEffect(() => {
    const loadInvoices = async () => {
      setIsLoading(true);
      isUpdatingRef.current = true;
      try {
        await InvoiceCacheService.fetchAllInvoices();
        
        // Manually update state after initial load
        const market = InvoiceCacheService.getMarketInvoices(address || undefined);
        setMarketInvoices(market);
        
        if (address) {
          const company = InvoiceCacheService.getCompanyInvoices(address);
          const investor = InvoiceCacheService.getInvestorInvoices(address);
          setCompanyInvoices(company);
          setInvestorInvoices(investor);
        }
      } catch (error) {
        console.error('Error loading invoices:', error);
      } finally {
        setIsLoading(false);
        isUpdatingRef.current = false;
      }
    };

    loadInvoices();
  }, []);

  // Update user context when wallet connects/disconnects
  useEffect(() => {
    if (address && address !== lastAddressRef.current) {
      lastAddressRef.current = address;
      InvoiceCacheService.setCurrentUserAddress(address);
    } else if (!address && lastAddressRef.current) {
      lastAddressRef.current = null;
      InvoiceCacheService.setCurrentUserAddress(null);
      setCompanyInvoices([]);
      setInvestorInvoices([]);
    }
  }, [address]);

  const refresh = async () => {
    if (!isUpdatingRef.current) {
      setIsLoading(true);
      isUpdatingRef.current = true;
      try {
        await InvoiceCacheService.fetchAllInvoices(true);
      } catch (error) {
        console.error('Error refreshing invoices:', error);
        throw error;
      } finally {
        setIsLoading(false);
        isUpdatingRef.current = false;
      }
    }
  };

  const invalidateAndRefresh = async () => {
    if (!isUpdatingRef.current) {
      setIsLoading(true);
      isUpdatingRef.current = true;
      try {
        InvoiceCacheService.invalidateCache();
        await InvoiceCacheService.fetchAllInvoices(true);
      } catch (error) {
        console.error('Error invalidating and refreshing invoices:', error);
        throw error;
      } finally {
        setIsLoading(false);
        isUpdatingRef.current = false;
      }
    }
  };

  return (
    <InvoiceCacheContext.Provider
      value={{
        companyInvoices,
        investorInvoices,
        marketInvoices,
        isLoading,
        refresh,
        invalidateAndRefresh,
      }}
    >
      {children}
    </InvoiceCacheContext.Provider>
  );
}

export function useInvoiceCache() {
  const context = useContext(InvoiceCacheContext);
  if (!context) {
    throw new Error('useInvoiceCache must be used within InvoiceCacheProvider');
  }
  return context;
}
