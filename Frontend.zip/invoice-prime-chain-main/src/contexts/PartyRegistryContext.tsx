import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { useWallet } from '@/hooks/useWallet';
import { partyRegistryService, type PartyStatus } from '@/services/partyRegistryService';

interface PartyRegistryContextValue {
  status: PartyStatus | null;
  loading: boolean;
  refresh: () => Promise<void>;
  invalidateAndRefresh: () => Promise<void>;
}

const PartyRegistryContext = createContext<PartyRegistryContextValue | undefined>(undefined);

export function PartyRegistryProvider({ children }: { children: ReactNode }) {
  const { address, isConnected } = useWallet();
  const [status, setStatus] = useState<PartyStatus | null>(null);
  const [loading, setLoading] = useState(false);

  // Load initial status when wallet connects
  useEffect(() => {
    if (!isConnected || !address) {
      setStatus(null);
      partyRegistryService.clearAll();
      return;
    }

    let mounted = true;

    const loadStatus = async () => {
      setLoading(true);
      try {
        const newStatus = await partyRegistryService.getStatus(address);
        if (mounted) {
          setStatus(newStatus);
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    loadStatus();

    return () => {
      mounted = false;
    };
  }, [address, isConnected]);

  // Subscribe to status updates from the service
  useEffect(() => {
    if (!address) return;

    const unsubscribe = partyRegistryService.subscribe((newStatus) => {
      setStatus(newStatus);
    });

    return unsubscribe;
  }, [address]);

  const refresh = useCallback(async () => {
    if (!address) return;
    
    setLoading(true);
    try {
      const newStatus = await partyRegistryService.getStatus(address, true);
      setStatus(newStatus);
    } finally {
      setLoading(false);
    }
  }, [address]);

  const invalidateAndRefresh = useCallback(async () => {
    if (!address) return;
    
    setLoading(true);
    try {
      const newStatus = await partyRegistryService.invalidateAndRefresh(address);
      setStatus(newStatus);
    } finally {
      setLoading(false);
    }
  }, [address]);

  return (
    <PartyRegistryContext.Provider value={{ status, loading, refresh, invalidateAndRefresh }}>
      {children}
    </PartyRegistryContext.Provider>
  );
}

export function usePartyRegistry() {
  const context = useContext(PartyRegistryContext);
  if (context === undefined) {
    throw new Error('usePartyRegistry must be used within a PartyRegistryProvider');
  }
  return context;
}
