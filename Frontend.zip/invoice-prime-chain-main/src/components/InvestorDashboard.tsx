import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, TrendingUp, RefreshCw, Wallet } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/hooks/useWallet";
import { useInvoiceCache } from "@/contexts/InvoiceCacheContext";
import type { InvestorInvoice } from "@/lib/blockchain";

const InvestorDashboard = () => {
  const navigate = useNavigate();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { toast } = useToast();
  const { isConnected, connectWallet } = useWallet();
  const { investorInvoices: investments, isLoading, invalidateAndRefresh } = useInvoiceCache();

  const handleRefresh = async () => {
    try {
      setIsRefreshing(true);
      await invalidateAndRefresh();
      toast({
        title: "Refreshed",
        description: "All NFTs have been refreshed",
      });
    } catch (error) {
      console.error('Error refreshing investments:', error);
      toast({
        title: "Error",
        description: "Failed to refresh investments",
        variant: "destructive",
      });
    } finally {
      setIsRefreshing(false);
    }
  };
  const getStatusIcon = (status: InvestorInvoice['status']) => {
    switch (status) {
      case 'settled': return <CheckCircle className="w-5 h-5" />;
      case 'active': return <TrendingUp className="w-5 h-5" />;
    }
  };
  
  const getStatusColor = (status: InvestorInvoice['status']) => {
    switch (status) {
      case 'settled': return 'bg-neon-green text-foreground';
      case 'active': return 'bg-electric-blue text-background';
    }
  };

  const totalInvested = investments.reduce((sum, inv) => sum + inv.investmentAmount, 0);
  const totalReturns = investments
    .filter(inv => inv.status === 'settled')
    .reduce((sum, inv) => sum + inv.expectedReturn, 0);
  const activeInvestments = investments.filter(inv => inv.status === 'active').length;
  const avgReturn = investments.length > 0
    ? (investments.reduce((sum, inv) => sum + inv.discountRate, 0) / investments.length).toFixed(1)
    : '0.0';

  return (
    <div className="container mx-auto px-4 md:px-6 py-6 md:py-8">
      {/* Header */}
      <div className="mb-6 md:mb-8">
        <div className="brutal-card p-2 inline-block mb-3 md:mb-4 bg-card">
          <span className="text-xs md:text-sm font-black uppercase tracking-wider text-steel">
            INVESTOR DASHBOARD
          </span>
        </div>
        <h1 className="text-2xl md:text-3xl lg:text-4xl font-black mb-2">
          YOUR <span className="electric-text">INVESTMENTS</span>
        </h1>
        <p className="text-sm md:text-base lg:text-lg text-steel font-medium">
          Monitor SWIFT transactions and blockchain settlement status
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
        <div className="brutal-card p-6 bg-electric-blue">
          <div className="text-3xl font-black text-background">
            ${totalInvested.toLocaleString()}
          </div>
          <div className="text-sm font-bold text-background uppercase">
            TOTAL INVESTED
          </div>
        </div>
        
        <div className="brutal-card p-6 bg-neon-green">
          <div className="text-3xl font-black text-foreground">
            ${totalReturns.toLocaleString()}
          </div>
          <div className="text-sm font-bold text-foreground uppercase">
            REALIZED RETURNS
          </div>
        </div>
        
        <div className="brutal-card p-6 bg-electric-yellow">
          <div className="text-3xl font-black text-foreground">
            {activeInvestments}
          </div>
          <div className="text-sm font-bold text-foreground uppercase">
            ACTIVE POSITIONS
          </div>
        </div>
        
        <div className="brutal-card p-6 bg-hot-pink">
          <div className="text-3xl font-black text-background">
            {avgReturn}%
          </div>
          <div className="text-sm font-bold text-background uppercase">
            AVG DISCOUNT
          </div>
        </div>
      </div>

      {/* Investments List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black uppercase">INVESTMENT PORTFOLIO</h2>
          <Button 
            variant="brutal-outline" 
            size="sm" 
            className="uppercase"
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            REFRESH
          </Button>
        </div>
        
        {isLoading ? (
          <div className="brutal-card p-12 bg-card text-center">
            <div className="text-xl font-black text-steel">LOADING INVESTMENTS...</div>
          </div>
        ) : !isConnected ? (
          <div className="brutal-card p-12 bg-card text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-electric-blue brutal-border flex items-center justify-center">
              <Wallet className="w-8 h-8 text-background" />
            </div>
            <div className="text-xl font-black text-foreground mb-2">
              WALLET NOT CONNECTED
            </div>
            <div className="text-steel mb-6">
              Connect your wallet to view your investments
            </div>
            <Button variant="brutal" onClick={connectWallet}>
              CONNECT WALLET
            </Button>
          </div>
        ) : investments.length === 0 ? (
          <div className="brutal-card p-12 bg-card text-center">
            <div className="text-xl font-black text-steel mb-2">NO INVESTMENTS YET</div>
            <div className="text-steel">Visit the market to start investing</div>
          </div>
        ) : (
          investments.map((investment) => (
          <div key={investment.tokenId} className="brutal-card p-4 md:p-6 bg-card">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 md:gap-6 items-start">
              {/* Investment Info */}
              <div>
                <div className="font-black text-lg mb-1">{investment.invoiceNumber}</div>
                <div className="font-bold text-foreground mb-1">{investment.company}</div>
                <div className="text-xs text-steel font-medium mb-1">{investment.industry}</div>
                <div className="text-sm text-steel font-medium">
                  Invested: {investment.purchaseDate}
                </div>
              </div>
              
              {/* Financial Details */}
              <div className="text-center">
                <div className="text-2xl font-black text-foreground">
                  ${investment.investmentAmount.toLocaleString()} {investment.currency}
                </div>
                <div className="text-sm font-bold text-steel uppercase">
                  INVESTED
                </div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-black neon-accent">
                  ${investment.expectedReturn.toLocaleString()} {investment.currency}
                </div>
                <div className="text-sm font-bold text-steel uppercase">
                  EXPECTED
                </div>
                <div className="text-xs text-steel">
                  +{investment.discountRate.toFixed(1)}% return
                </div>
              </div>
              
              {/* Status */}
              <div>
                <Badge className={`brutal-border font-black mb-2 ${getStatusColor(investment.status)}`}>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(investment.status)}
                    {investment.status.toUpperCase()}
                  </div>
                </Badge>
                <div className="text-sm font-medium text-steel">
                  Due: {investment.dueDate}
                </div>
                <div className="text-xs text-steel">
                  {investment.daysUntilDue} days left
                </div>
              </div>
            </div>
            
            {/* Simplified Status Display */}
            {investment.status === 'settled' && (
              <div className="mt-6 pt-6 border-t-4 border-border">
                <div className="brutal-card p-4 bg-neon-green">
                  <div className="font-black text-foreground mb-1">✓ SETTLEMENT COMPLETE</div>
                  <div className="text-sm text-foreground">Invoice has been settled and funds received</div>
                </div>
              </div>
            )}
          </div>
          ))
        )}
      </div>

    </div>
  );
};

export default InvestorDashboard;