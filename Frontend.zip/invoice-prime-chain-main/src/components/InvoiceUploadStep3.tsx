import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { useWallet } from '@/hooks/useWallet';
import { usePartyRegistry } from '@/contexts/PartyRegistryContext';
import { supabase } from '@/integrations/supabase/client';
import { mintInvoiceNFTWithViem, registerParty, approveMarketplaceForInvoice } from '@/lib/blockchain';
import { FileText, DollarSign, Wallet, CheckCircle, Loader2, Shield, UserPlus, Upload, AlertTriangle } from 'lucide-react';
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

interface InvoiceData {
  file: File | null;
  amount: string;
  issueDate: string;
  dueDate: string;
  paymentTarget: string;
  currency: string;
  description: string;
  companyName: string;
  industry: string;
  paymentMethod: 'swift' | 'stablecoin' | null;
}

interface InvoiceUploadStep3Props {
  data: InvoiceData;
  onComplete: () => void;
}

const leiSchema = z.object({
  lei: z.string()
    .min(20, "LEI must be exactly 20 characters")
    .max(20, "LEI must be exactly 20 characters")
    .regex(/^[A-Z0-9]{20}$/, "LEI must contain only uppercase letters and numbers"),
  vlei: z.string().min(1, "vLEI is required"),
});

type LEIFormData = z.infer<typeof leiSchema>;

const InvoiceUploadStep3 = ({ data, onComplete }: InvoiceUploadStep3Props) => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [mintedTokenId, setMintedTokenId] = useState<string | null>(null);
  const [needsApproval, setNeedsApproval] = useState(false);
  const [isApproving, setIsApproving] = useState(false);
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [isRegisterDialogOpen, setIsRegisterDialogOpen] = useState<boolean>(false);
  const { toast } = useToast();
  const { isConnected, address, connectWallet } = useWallet();
  const { status: partyStatus, invalidateAndRefresh } = usePartyRegistry();

  const form = useForm<LEIFormData>({
    resolver: zodResolver(leiSchema),
    defaultValues: {
      lei: "",
      vlei: "",
    },
  });

  const handleUploadToIPFS = async () => {
    if (!isConnected || !data.file) {
      toast({
        title: "Error",
        description: "Please connect your wallet and ensure file is selected",
        variant: "destructive",
      });
      return;
    }

    if (!partyStatus?.isTrusted) {
      toast({
        title: "Cannot Upload",
        description: "Your address must be registered and trusted to mint invoices",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    
    try {
      toast({
        title: "Uploading to IPFS...",
        description: "Your invoice is being uploaded to the decentralized network",
      });

      // Convert file to base64
      const fileBase64 = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = reader.result as string;
          resolve(result.split(',')[1]); // Remove data:type;base64, prefix
        };
        reader.readAsDataURL(data.file);
      });

      // Call Supabase Edge Function to upload to Pinata
      const { data: uploadResult, error } = await supabase.functions.invoke('upload-to-pinata', {
        body: {
          file: fileBase64,
          fileName: data.file.name,
          metadata: {
            companyName: data.companyName,
            amount: data.amount,
            currency: data.currency,
            issueDate: data.issueDate,
            dueDate: data.dueDate,
            paymentTarget: data.paymentTarget,
            paymentMethod: data.paymentMethod,
            description: data.description,
            uploadedAt: new Date().toISOString()
          }
        }
      });

      if (error) {
        throw new Error(error.message);
      }

      if (!uploadResult.success) {
        throw new Error(uploadResult.error || 'Upload failed');
      }

      // Now mint the NFT with the IPFS hash using viem
      toast({
        title: "Minting Invoice NFT",
        description: "Please sign the transaction in MetaMask to mint your invoice NFT",
      });

      const result = await mintInvoiceNFTWithViem(data, uploadResult.ipfsHash);
      setMintedTokenId(result.tokenId);
      
      setUploadComplete(true);
      
      // If invoice is listed, prompt for marketplace approval
      if (data.paymentMethod) {
        setNeedsApproval(true);
        toast({
          title: "Mint Successful!",
          description: "Now approve the marketplace to enable sales",
        });
      } else {
        toast({
          title: "Upload & Mint Successful!",
          description: `Your invoice has been uploaded to IPFS and minted as NFT`,
        });
        setTimeout(() => {
          onComplete();
        }, 2000);
      }
      
    } catch (error) {
      console.error('Upload failed:', error);
      let errorMessage = "There was an error uploading your invoice. Please try again.";
      
      if (error instanceof Error) {
        if (error.message.includes('UNTRUSTED_ADDRESS')) {
          errorMessage = "Your address is not trusted. Please ensure you're registered and verified in the PartyRegistry.";
        } else {
          errorMessage = error.message;
        }
      }
      
      toast({
        title: "Upload Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleRegister = async (data: LEIFormData) => {
    setIsRegistering(true);
    try {
      await registerParty(data.lei, data.vlei);
      toast({
        title: "Registration Successful!",
        description: "Please wait for verification.",
      });
      setIsRegisterDialogOpen(false);
      form.reset();
      // Refresh status after registration
      await invalidateAndRefresh();
    } catch (error) {
      console.error("Registration failed:", error);
      toast({
        title: "Registration Failed",
        description: "Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsRegistering(false);
    }
  };

  const handleApproveMarketplace = async () => {
    if (!mintedTokenId) return;
    
    setIsApproving(true);
    try {
      toast({
        title: "Approving Marketplace",
        description: "Please sign the transaction to approve the marketplace",
      });
      
      await approveMarketplaceForInvoice(mintedTokenId);
      
      toast({
        title: "Approval Successful!",
        description: "Your invoice can now be purchased on the marketplace",
      });
      
      setTimeout(() => {
        onComplete();
      }, 2000);
    } catch (error) {
      console.error('Approval failed:', error);
      toast({
        title: "Approval Failed",
        description: "You can approve the marketplace later from your dashboard",
        variant: "destructive",
      });
    } finally {
      setIsApproving(false);
    }
  };

  if (uploadComplete && needsApproval) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center">
        <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
        <h3 className="text-2xl font-black uppercase mb-2">Mint Complete!</h3>
        <p className="text-steel mb-4">Your invoice has been minted as NFT #{mintedTokenId}</p>
        
        <div className="brutal-card p-6 bg-electric-yellow max-w-md mb-6">
          <Shield className="w-12 h-12 mx-auto mb-3 text-foreground" />
          <h4 className="font-black text-lg mb-2 text-foreground">MARKETPLACE APPROVAL REQUIRED</h4>
          <p className="text-sm text-foreground font-medium mb-4">
            To enable sales on the marketplace, you must approve the marketplace contract to transfer your NFT when a buyer purchases it.
          </p>
          <Button
            variant="brutal"
            size="lg"
            onClick={handleApproveMarketplace}
            disabled={isApproving}
            className="w-full uppercase"
          >
            {isApproving ? "APPROVING..." : "APPROVE MARKETPLACE"}
          </Button>
        </div>
        
        <Button onClick={onComplete} variant="outline" className="uppercase font-bold">
          Skip for Now (Approve Later)
        </Button>
      </div>
    );
  }

  if (uploadComplete) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center">
        <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
        <h3 className="text-2xl font-black uppercase mb-2">Upload & Mint Complete!</h3>
        <p className="text-steel mb-4">Your invoice has been successfully uploaded to IPFS and minted as an NFT.</p>
        {mintedTokenId && (
          <p className="text-sm text-steel mb-6">Token ID: {mintedTokenId}</p>
        )}
        <Button onClick={onComplete} className="uppercase font-bold">
          Return to Dashboard
        </Button>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-8">
      <div className="text-center">
        <h3 className="text-2xl font-black uppercase mb-4">Review & Confirm</h3>
        <p className="text-steel font-medium">Please review all details before uploading to IPFS</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Invoice Details */}
        <div className="space-y-6">
          <Card className="p-6">
            <h4 className="text-lg font-black uppercase mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Invoice Details
            </h4>
            
            <div className="space-y-4">
              {data.file && (
                <div className="flex items-center justify-between">
                  <span className="font-medium">File:</span>
                  <span className="text-sm text-steel">{data.file.name}</span>
                </div>
              )}
              
              <div className="flex items-center justify-between">
                <span className="font-medium">Company:</span>
                <span className="font-bold">{data.companyName}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-medium">Amount:</span>
                <span className="text-xl font-black text-primary">
                  {data.amount} {data.currency}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-medium">Issue Date:</span>
                <span>{data.issueDate}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-medium">Due Date:</span>
                <span>{data.dueDate}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-medium">Payment Target:</span>
                <Badge variant="outline">{data.paymentTarget}</Badge>
              </div>
              
              {data.description && (
                <div>
                  <span className="font-medium">Description:</span>
                  <p className="text-sm text-steel mt-1">{data.description}</p>
                </div>
              )}
            </div>
          </Card>

          {/* Payment Method */}
          <Card className="p-6">
            <h4 className="text-lg font-black uppercase mb-4 flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Payment Method
            </h4>
            
            <div className="flex items-center justify-between">
              <span className="font-medium">Selected Method:</span>
              <Badge variant="outline" className="capitalize font-bold">
                {data.paymentMethod === 'swift' ? 'SWIFT Transfer' : 'Stablecoin'}
              </Badge>
            </div>
          </Card>
        </div>

        {/* Wallet & Upload */}
        <div className="space-y-6">
          <Card className="p-6">
            <h4 className="text-lg font-black uppercase mb-4 flex items-center gap-2">
              <Wallet className="w-5 h-5" />
              Wallet Connection
            </h4>
            
            {isConnected ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Status:</span>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    Connected
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-medium">Address:</span>
                  <span className="font-mono text-sm">{address?.slice(0, 6)}...{address?.slice(-4)}</span>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-steel">
                  You need to connect your wallet to sign the transaction.
                </p>
                <Button onClick={connectWallet} variant="outline" className="w-full">
                  Connect Wallet
                </Button>
              </div>
            )}
          </Card>

          {/* Trust Status */}
          {isConnected && (
            <Card className="p-6">
              <h4 className="text-lg font-black uppercase mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Registry Status
              </h4>
              
              {!partyStatus && (
                <div className="flex items-center gap-3">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-sm">Checking registry status...</span>
                </div>
              )}
              
              {partyStatus?.isTrusted && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Status:</span>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      Trusted
                    </Badge>
                  </div>
                  {partyStatus.party && (
                    <div className="flex items-center justify-between">
                      <span className="font-medium">LEI:</span>
                      <span className="font-mono text-sm">{partyStatus.party.lei}</span>
                    </div>
                  )}
                </div>
              )}
              
              {partyStatus?.isRegistered && !partyStatus.isTrusted && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Status:</span>
                    <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                      Registered - Pending Verification
                    </Badge>
                  </div>
                  {partyStatus.party && (
                    <div className="flex items-center justify-between">
                      <span className="font-medium">LEI:</span>
                      <span className="font-mono text-sm">{partyStatus.party.lei}</span>
                    </div>
                  )}
                  <p className="text-sm text-steel">
                    Your registration is pending verification by the oracle. Please wait for approval.
                  </p>
                </div>
              )}
              
              {!partyStatus?.isRegistered && partyStatus && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Status:</span>
                    <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                      Not Registered
                    </Badge>
                  </div>
                  <p className="text-sm text-steel">
                    You must register in the PartyRegistry with a valid LEI to mint invoices.
                  </p>
                  
                  <Dialog open={isRegisterDialogOpen} onOpenChange={setIsRegisterDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="brutal" size="sm" className="w-full uppercase">
                        <UserPlus className="mr-2 w-4 h-4" />
                        Register with LEI
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle className="font-black text-xl">REGISTER WITH LEI</DialogTitle>
                      </DialogHeader>
                      
                      <div className="space-y-4">
                        <div className="brutal-card p-4 bg-electric-yellow">
                          <p className="text-sm font-bold text-foreground">
                            ⚠️ You need a valid Legal Entity Identifier (LEI) from GLEIF to register.
                          </p>
                        </div>
                        
                        <Form {...form}>
                          <form onSubmit={form.handleSubmit(handleRegister)} className="space-y-4">
                            <FormField
                              control={form.control}
                              name="lei"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel className="font-bold uppercase">LEI (20 characters)</FormLabel>
                                  <FormControl>
                                    <Input
                                      {...field}
                                      placeholder="Enter your LEI code"
                                      className="uppercase font-mono"
                                      maxLength={20}
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="vlei"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel className="font-bold uppercase">vLEI (Virtual LEI)</FormLabel>
                                  <FormControl>
                                    <Input
                                      {...field}
                                      placeholder="Enter your vLEI"
                                      className="font-mono"
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <div className="flex gap-3">
                              <Button 
                                type="submit" 
                                variant="brutal" 
                                disabled={isRegistering}
                                className="flex-1"
                              >
                                {isRegistering ? "REGISTERING..." : "REGISTER"}
                              </Button>
                              <Button 
                                type="button" 
                                variant="brutal-outline" 
                                onClick={() => setIsRegisterDialogOpen(false)}
                              >
                                CANCEL
                              </Button>
                            </div>
                          </form>
                        </Form>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              )}
            </Card>
          )}

          <Card className="p-6">
            <h4 className="text-lg font-black uppercase mb-4 flex items-center gap-2">
              <Upload className="w-5 h-5" />
              IPFS Upload
            </h4>
            
            <div className="space-y-4">
              <p className="text-sm text-steel">
                Your invoice will be uploaded to IPFS via Pinata for decentralized storage. 
                A MetaMask signature will be required to confirm the transaction.
              </p>
              
              <Button
                onClick={handleUploadToIPFS}
                disabled={!isConnected || isUploading || !partyStatus?.isTrusted}
                className="w-full uppercase font-bold"
                size="lg"
              >
                {isUploading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Uploading to IPFS...
                  </>
                ) : !partyStatus?.isTrusted ? (
                  <>
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    Registration Required
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Upload & Sign
                  </>
                )}
              </Button>
            </div>
          </Card>
        </div>
      </div>

      {isUploading && (
        <Card className="p-6 bg-blue-50 border-blue-200">
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
              <span className="font-bold">Processing Upload...</span>
            </div>
            
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                <span>Uploading to IPFS via Pinata...</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                <span>Minting Invoice NFT...</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-steel rounded-full"></div>
                <span>Awaiting MetaMask signature...</span>
              </div>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};

export default InvoiceUploadStep3;