import { Button } from "@/components/ui/button";
import { ArrowRight, DollarSign, Zap } from "lucide-react";
import InvoiceFlowVisual from "@/components/InvoiceFlowVisual";
import { useNavigate } from "react-router-dom";

const Hero = () => {
  const navigate = useNavigate();
  
  return (
    <section className="min-h-screen bg-background industrial-grid">
      <div className="container mx-auto px-4 md:px-6 py-12 md:py-20">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Left Column - Content */}
          <div className="space-y-6 md:space-y-8">
            <div className="space-y-4 md:space-y-6">
              <div className="brutal-card p-2 inline-block bg-card">
                <span className="text-xs md:text-sm font-black uppercase tracking-wider text-steel">
                  BLOCKCHAIN FACTORING
                </span>
              </div>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-black leading-tight">
                SELL YOUR
                <br />
                <span className="electric-text">INVOICES</span>
                <br />
                <span className="neon-accent">INSTANTLY</span>
              </h1>
              
              <p className="text-base md:text-xl font-medium text-steel max-w-lg">
                Convert future payments into immediate cash flow. Our blockchain-powered 
                platform connects businesses with investors for secure, transparent 
                invoice factoring.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="brutal" size="lg" className="uppercase" onClick={() => navigate("/company")}>
                <DollarSign className="mr-2" />
                Start Factoring
                <ArrowRight className="ml-2" />
              </Button>
              
              <Button variant="brutal-outline" size="lg" className="uppercase" onClick={() => {
                document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
              }}>
                <Zap className="mr-2" />
                Learn More
              </Button>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-4 md:pt-8">
              <div className="brutal-card p-4 md:p-6 bg-electric-blue">
                <div className="text-2xl md:text-3xl font-black text-background">$2.4M+</div>
                <div className="text-xs md:text-sm font-bold text-background uppercase">
                  FACTORED
                </div>
              </div>
              <div className="brutal-card p-4 md:p-6 bg-neon-green">
                <div className="text-2xl md:text-3xl font-black text-foreground">24H</div>
                <div className="text-xs md:text-sm font-bold text-foreground uppercase">
                  AVG SETTLEMENT
                </div>
              </div>
              <div className="brutal-card p-4 md:p-6 bg-hot-pink col-span-2 sm:col-span-1">
                <div className="text-2xl md:text-3xl font-black text-background">500+</div>
                <div className="text-xs md:text-sm font-bold text-background uppercase">
                  COMPANIES
                </div>
              </div>
            </div>
          </div>
          
          {/* Right Column - Visual */}
          <div className="relative">
            <InvoiceFlowVisual />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;