import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, AlertTriangle, Zap } from "lucide-react";
import { useState } from "react";

interface Transaction {
  id: string;
  invoice: string;
  amount: number;
  status: 'pending' | 'confirmed' | 'settled' | 'failed';
  timestamp: string;
  blockHash: string;
  swiftRef?: string;
}

const mockTransactions: Transaction[] = [
  {
    id: "0x1a2b3c",
    invoice: "INV-2024-001",
    amount: 25000,
    status: 'settled',
    timestamp: '2024-01-15 14:32',
    blockHash: '0x4d5e6f7a8b9c',
    swiftRef: 'FT24015001'
  },
  {
    id: "0x2b3c4d",
    invoice: "INV-2024-002", 
    amount: 15500,
    status: 'confirmed',
    timestamp: '2024-01-15 16:45',
    blockHash: '0x5e6f7a8b9c0d',
    swiftRef: 'FT24015002'
  },
  {
    id: "0x3c4d5e",
    invoice: "INV-2024-003",
    amount: 8200,
    status: 'pending',
    timestamp: '2024-01-15 18:12',
    blockHash: '0x6f7a8b9c0d1e'
  }
];

const BlockchainTracker = () => {
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  
  const getStatusIcon = (status: Transaction['status']) => {
    switch (status) {
      case 'settled': return <CheckCircle className="w-5 h-5" />;
      case 'confirmed': return <Zap className="w-5 h-5" />;
      case 'pending': return <Clock className="w-5 h-5" />;
      case 'failed': return <AlertTriangle className="w-5 h-5" />;
    }
  };
  
  const getStatusColor = (status: Transaction['status']) => {
    switch (status) {
      case 'settled': return 'bg-neon-green text-foreground';
      case 'confirmed': return 'bg-electric-blue text-background';
      case 'pending': return 'bg-electric-yellow text-foreground';
      case 'failed': return 'bg-danger text-danger-foreground';
    }
  };

  return (
    <section className="py-12 md:py-20 bg-surface">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12 md:mb-16">
          <div className="brutal-card p-2 inline-block mb-4 md:mb-6 bg-card">
            <span className="text-xs md:text-sm font-black uppercase tracking-wider text-steel">
              BLOCKCHAIN TRACKING
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-black mb-4 md:mb-6">
            TRANSPARENT
            <br />
            <span className="electric-text">SETTLEMENT</span>
          </h2>
          <p className="text-base md:text-xl text-steel max-w-2xl mx-auto">
            Every transaction is recorded on-chain with SWIFT integration 
            for real-time payment verification.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
          {/* Transaction List */}
          <div className="lg:col-span-2 space-y-4">
            {mockTransactions.map((tx) => (
              <div 
                key={tx.id}
                className={`brutal-card p-4 md:p-6 cursor-pointer transition-all ${
                  selectedTx?.id === tx.id ? 'bg-electric-blue' : 'bg-card'
                }`}
                onClick={() => setSelectedTx(tx)}
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                  <div className="flex items-center gap-3 md:gap-4">
                    <div className={`brutal-border p-2 ${getStatusColor(tx.status)}`}>
                      {getStatusIcon(tx.status)}
                    </div>
                    <div>
                      <div className={`font-black text-base md:text-lg ${
                        selectedTx?.id === tx.id ? 'text-background' : 'text-foreground'
                      }`}>
                        {tx.invoice}
                      </div>
                      <div className={`text-xs md:text-sm font-medium ${
                        selectedTx?.id === tx.id ? 'text-background/80' : 'text-steel'
                      }`}>
                        TX: {tx.id}
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-left md:text-right">
                    <div className={`text-xl md:text-2xl font-black ${
                      selectedTx?.id === tx.id ? 'text-background' : 'text-foreground'
                    }`}>
                      ${tx.amount.toLocaleString()}
                    </div>
                    <div className={`text-xs md:text-sm font-medium ${
                      selectedTx?.id === tx.id ? 'text-background/80' : 'text-steel'
                    }`}>
                      {tx.timestamp}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Badge className={`brutal-border font-black ${getStatusColor(tx.status)}`}>
                    {tx.status.toUpperCase()}
                  </Badge>
                  {tx.swiftRef && (
                    <Badge className="brutal-border bg-concrete text-steel font-black">
                      SWIFT: {tx.swiftRef}
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          {/* Transaction Details */}
          <div className="brutal-card p-6 bg-card h-fit">
            {selectedTx ? (
              <div className="space-y-6">
                <h3 className="text-2xl font-black uppercase">
                  TRANSACTION DETAILS
                </h3>
                
                <div className="space-y-4">
                  <div>
                    <div className="text-sm font-black uppercase text-steel mb-1">
                      INVOICE
                    </div>
                    <div className="font-bold text-lg">{selectedTx.invoice}</div>
                  </div>
                  
                  <div>
                    <div className="text-sm font-black uppercase text-steel mb-1">
                      AMOUNT
                    </div>
                    <div className="text-2xl font-black electric-text">
                      ${selectedTx.amount.toLocaleString()}
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-sm font-black uppercase text-steel mb-1">
                      STATUS
                    </div>
                    <Badge className={`brutal-border font-black ${getStatusColor(selectedTx.status)}`}>
                      {selectedTx.status.toUpperCase()}
                    </Badge>
                  </div>
                  
                  <div>
                    <div className="text-sm font-black uppercase text-steel mb-1">
                      BLOCK HASH
                    </div>
                    <div className="font-mono text-sm break-all bg-surface p-2 brutal-border">
                      {selectedTx.blockHash}
                    </div>
                  </div>
                  
                  {selectedTx.swiftRef && (
                    <div>
                      <div className="text-sm font-black uppercase text-steel mb-1">
                        SWIFT REFERENCE
                      </div>
                      <div className="font-mono font-bold">
                        {selectedTx.swiftRef}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="text-steel text-lg font-medium">
                  SELECT A TRANSACTION TO VIEW DETAILS
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default BlockchainTracker;