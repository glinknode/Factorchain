import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Wallet, Loader2 } from "lucide-react";
import { useWallet } from "@/hooks/useWallet";
import { useState, useEffect } from "react";

interface WalletConnectDialogProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description: string;
  onConnect?: () => void;
}

const WalletConnectDialog = ({ 
  isOpen, 
  onClose, 
  title, 
  description,
  onConnect 
}: WalletConnectDialogProps) => {
  const { connectWallet, isConnected, isLoading } = useWallet();
  const [isConnecting, setIsConnecting] = useState(false);

  // Auto-close when wallet connects
  useEffect(() => {
    if (isConnected && isOpen) {
      onConnect?.();
      onClose();
    }
  }, [isConnected, isOpen, onClose, onConnect]);

  const handleConnect = async () => {
    try {
      setIsConnecting(true);
      await connectWallet();
    } catch (error) {
      console.error('Failed to connect wallet:', error);
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="brutal-card max-w-md">
        <DialogHeader>
          <div className="w-16 h-16 mx-auto mb-4 bg-electric-blue brutal-border flex items-center justify-center">
            <Wallet className="w-8 h-8 text-background" />
          </div>
          <DialogTitle className="text-2xl font-black text-center">
            {title}
          </DialogTitle>
          <DialogDescription className="text-center text-steel font-medium text-base mt-2">
            {description}
          </DialogDescription>
        </DialogHeader>
        
        <div className="mt-6">
          <Button 
            variant="brutal" 
            size="lg" 
            className="w-full uppercase"
            onClick={handleConnect}
            disabled={isConnecting || isLoading}
          >
            {isConnecting || isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                CONNECTING...
              </>
            ) : (
              <>
                <Wallet className="w-4 h-4 mr-2" />
                CONNECT WALLET
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default WalletConnectDialog;
