import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { AlertTriangle, CheckCircle, UserPlus, Clock } from "lucide-react";
import { useWallet } from "@/hooks/useWallet";
import { usePartyRegistry } from "@/contexts/PartyRegistryContext";
import { registerParty, validateLEICheckDigits } from "@/lib/blockchain";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";

interface PartyRegistryStatusProps {
  purpose?: 'mint' | 'invest';
  compact?: boolean;
}

const leiSchema = z.object({
  lei: z.string()
    .trim()
    .length(20, "LEI must be exactly 20 characters")
    .regex(/^[0-9A-Z]{18}[0-9]{2}$/, "LEI format: 18 alphanumeric chars + 2 check digits")
    .refine((lei) => validateLEICheckDigits(lei), {
      message: "Invalid LEI check digits. Please verify your LEI code."
    }),
  vlei: z.string()
    .trim()
    .min(10, "vLEI credential is too short")
    .refine((vlei) => {
      // Accept hex string (0x...) or JSON credential
      return vlei.startsWith('0x') || vlei.startsWith('{') || vlei.length >= 32;
    }, {
      message: "vLEI must be hex (0x...), JSON credential, or valid hash"
    }),
});

type LEIFormData = z.infer<typeof leiSchema>;

const PartyRegistryStatus = ({ purpose = 'mint', compact = false }: PartyRegistryStatusProps) => {
  const { isConnected } = useWallet();
  const { status, loading, invalidateAndRefresh } = usePartyRegistry();
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [isDialogOpen, setIsDialogOpen] = useState<boolean>(false);

  const form = useForm<LEIFormData>({
    resolver: zodResolver(leiSchema),
    defaultValues: {
      lei: "",
      vlei: "",
    },
  });

  const handleRegister = async (data: LEIFormData) => {
    setIsRegistering(true);
    try {
      await registerParty(data.lei, data.vlei);
      toast.success("Registration successful! Please wait for verification.");
      setIsDialogOpen(false);
      form.reset();
      // Refresh status after registration
      await invalidateAndRefresh();
    } catch (error) {
      console.error("Registration failed:", error);
      toast.error("Registration failed. Please try again.");
    } finally {
      setIsRegistering(false);
    }
  };

  if (!isConnected) {
    return (
      <div className="brutal-card p-6 bg-card mb-8">
        <div className="flex items-center gap-4">
          <AlertTriangle className="w-6 h-6 text-warning" />
          <div>
            <h3 className="font-black text-lg mb-1">WALLET CONNECTION REQUIRED</h3>
            <p className="text-steel font-medium">Connect your wallet to check PartyRegistry status</p>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="brutal-card p-6 bg-card mb-8">
        <div className="flex items-center gap-4">
          <Clock className="w-6 h-6 text-steel animate-spin" />
          <div>
            <h3 className="font-black text-lg mb-1">CHECKING REGISTRATION STATUS...</h3>
            <p className="text-steel font-medium">Verifying your PartyRegistry registration</p>
          </div>
        </div>
      </div>
    );
  }

  const getStatusContent = () => {
    const action = purpose === 'mint' ? 'mint invoices' : 'invest in invoices';
    const canAction = purpose === 'mint' ? 'mint invoices' : 'invest';
    
    if (!status?.isRegistered) {
      // Not registered
      return {
        icon: <AlertTriangle className="w-6 h-6 text-danger" />,
        title: "NOT REGISTERED",
        description: `You must register in the PartyRegistry with a valid LEI to ${action}`,
        badge: <Badge className="bg-danger text-danger-foreground font-black">UNREGISTERED</Badge>,
        actionNeeded: true,
      };
    } else if (status.isTrusted) {
      // Registered and trusted
      return {
        icon: <CheckCircle className="w-6 h-6 text-neon-green" />,
        title: "VERIFIED & TRUSTED",
        description: `LEI: ${status.party?.lei} - You can ${canAction}`,
        badge: <Badge className="bg-neon-green text-foreground font-black">VERIFIED</Badge>,
        actionNeeded: false,
      };
    } else {
      // Registered but not yet trusted
      return {
        icon: <Clock className="w-6 h-6 text-electric-yellow" />,
        title: "PENDING VERIFICATION",
        description: `LEI: ${status.party?.lei} - Awaiting oracle verification`,
        badge: <Badge className="bg-electric-yellow text-foreground font-black">PENDING</Badge>,
        actionNeeded: false,
      };
    }
  };

  const statusContent = getStatusContent();

  return (
    <div className={`brutal-card ${compact ? 'p-4' : 'p-6'} bg-card ${compact ? '' : 'mb-8'}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4 flex-1">
          {statusContent.icon}
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h3 className={`font-black ${compact ? 'text-base' : 'text-lg'}`}>PARTYREGISTRY STATUS</h3>
              {statusContent.badge}
            </div>
            <p className={`text-steel font-medium ${compact ? 'text-sm' : ''}`}>{statusContent.description}</p>
          </div>
        </div>
        
        {statusContent.actionNeeded && (
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="brutal" size="lg" className="uppercase">
                <UserPlus className="mr-2" />
                REGISTER NOW
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="font-black text-xl">REGISTER WITH LEI</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="brutal-card p-4 bg-electric-yellow">
                  <p className="text-sm font-bold text-foreground mb-2">
                    ⚠️ You need a valid Legal Entity Identifier (LEI) from GLEIF to register.
                  </p>
                  <p className="text-xs font-medium text-foreground">
                    • LEI: 20 characters (e.g., 529900T8BM49AURSDO55)
                    <br />
                    • vLEI: Hex hash (0x...), JSON credential, or credential hash
                  </p>
                </div>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(handleRegister)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="lei"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="font-bold uppercase">LEI (20 characters)</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="Enter your LEI code"
                              className="uppercase font-mono"
                              maxLength={20}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="vlei"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="font-bold uppercase">vLEI Credential</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              placeholder="0x... or JSON credential"
                              className="font-mono text-sm"
                            />
                          </FormControl>
                          <p className="text-xs text-steel mt-1">
                            Accepts hex hash, JSON, or credential string
                          </p>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex gap-3">
                      <Button 
                        type="submit" 
                        variant="brutal" 
                        disabled={isRegistering}
                        className="flex-1"
                      >
                        {isRegistering ? "REGISTERING..." : "REGISTER"}
                      </Button>
                      <Button 
                        type="button" 
                        variant="brutal-outline" 
                        onClick={() => setIsDialogOpen(false)}
                      >
                        CANCEL
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
};

export default PartyRegistryStatus;