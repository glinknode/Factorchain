import { useTheme } from "next-themes";
import { Toaster as Sonner, toast } from "sonner";

type ToasterProps = React.ComponentProps<typeof Sonner>;

const Toaster = ({ ...props }: ToasterProps) => {
  const { theme = "system" } = useTheme();

  return (
    <Sonner
      theme={theme as ToasterProps["theme"]}
      position="top-right"
      className="toaster group"
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-white group-[.toaster]:text-foreground group-[.toaster]:border-[4px] group-[.toaster]:border-black group-[.toaster]:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] group-[.toaster]:rounded-none group-[.toaster]:font-bold",
          description: "group-[.toast]:text-steel group-[.toast]:font-medium",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground group-[.toast]:border-2 group-[.toast]:border-black group-[.toast]:font-black group-[.toast]:uppercase",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-foreground group-[.toast]:border-2 group-[.toast]:border-black group-[.toast]:font-black group-[.toast]:uppercase",
          error: "group-[.toast]:bg-white group-[.toast]:border-danger",
          success: "group-[.toast]:bg-white group-[.toast]:border-neon-green",
          warning: "group-[.toast]:bg-white group-[.toast]:border-electric-yellow",
          info: "group-[.toast]:bg-white group-[.toast]:border-electric-blue",
        },
      }}
      {...props}
    />
  );
};

export { Toaster, toast };
