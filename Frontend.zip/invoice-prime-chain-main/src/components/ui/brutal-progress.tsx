import { cn } from "@/lib/utils";

interface BrutalProgressProps {
  value: number;
  minValue?: number;
  maxValue?: number;
  color?: "violet" | "pink" | "red" | "orange" | "yellow" | "lime" | "cyan";
  showPercentage?: boolean;
  disabled?: boolean;
  rounded?: "none" | "md" | "full";
  className?: string;
}

const BrutalProgress = ({
  value = 0,
  minValue = 0,
  maxValue = 100,
  color = "cyan",
  showPercentage = true,
  disabled = false,
  rounded = "none",
  className,
}: BrutalProgressProps) => {
  const clampedValue = Math.min(maxValue, Math.max(value, minValue));
  const widthPercentage = ((clampedValue - minValue) / (maxValue - minValue)) * 100;

  return (
    <div
      className={cn(
        "w-full max-w-md border-black border-2 focus:outline-none h-9 overflow-hidden shadow-[2px_2px_0px_rgba(0,0,0,1)] bg-white",
        { "rounded-none": rounded === "none" },
        { "rounded-md": rounded === "md" },
        { "rounded-full": rounded === "full" },
        { "shadow-[2px_2px_0px_rgba(0,0,0,1)]": !disabled },
        {
          "border-[#727272] bg-[#D4D4D4] text-[#676767] hover:bg-[#D4D4D4] hover:shadow-none active:bg-[#D4D4D4]":
            disabled,
        },
        className
      )}
    >
      <div
        style={{ width: widthPercentage + "%" }}
        className={cn(
          "h-full flex flex-row items-center justify-end overflow-hidden",
          {
            "bg-violet-200 hover:bg-violet-300": color === "violet" && !disabled,
          },
          {
            "bg-pink-200 hover:bg-pink-300": color === "pink" && !disabled,
          },
          {
            "bg-red-200 hover:bg-red-300": color === "red" && !disabled,
          },
          {
            "bg-orange-200 hover:bg-orange-300": color === "orange" && !disabled,
          },
          {
            "bg-yellow-200 hover:bg-yellow-300": color === "yellow" && !disabled,
          },
          {
            "bg-lime-200 hover:bg-lime-300": color === "lime" && !disabled,
          },
          {
            "bg-cyan-200 hover:bg-cyan-300": color === "cyan" && !disabled,
          },
          { "rounded-none": rounded === "none" },
          { "rounded-md": rounded === "md" },
          { "rounded-full": rounded === "full" }
        )}
      >
        {showPercentage && (
          <div
            className={cn(
              "text-black text-sm flex-none px-2 font-bold",
              {
                "text-[#676767]": disabled,
              }
            )}
          >
            {Math.round(widthPercentage)}%
          </div>
        )}
      </div>
    </div>
  );
};

export { BrutalProgress };