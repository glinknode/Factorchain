import { TrendingUp, DollarSign, Clock, Shield } from "lucide-react";

const FactoringVisual = () => {
  return (
    <section id="how-it-works" className="py-12 md:py-20 bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12 md:mb-16">
          <div className="brutal-card p-2 inline-block mb-4 md:mb-6 bg-card">
            <span className="text-xs md:text-sm font-black uppercase tracking-wider text-steel">
              HOW IT WORKS
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-black mb-4 md:mb-6">
            INVOICE <span className="neon-accent">FACTORING</span>
            <br />
            SIMPLIFIED
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 mb-12 md:mb-16">
          {/* Step 1 */}
          <div className="text-center">
            <div className="brutal-card p-8 bg-electric-blue mb-6">
              <DollarSign className="w-12 h-12 text-background mx-auto" />
            </div>
            <h3 className="text-xl font-black uppercase mb-3">
              1. UPLOAD INVOICE
            </h3>
            <p className="text-steel font-medium">
              Submit your invoice details and payment terms to our platform
            </p>
          </div>

          {/* Step 2 */}
          <div className="text-center">
            <div className="brutal-card p-8 bg-neon-green mb-6">
              <TrendingUp className="w-12 h-12 text-foreground mx-auto" />
            </div>
            <h3 className="text-xl font-black uppercase mb-3">
              2. RISK ASSESSMENT
            </h3>
            <p className="text-steel font-medium">
              Our AI evaluates creditworthiness and calculates the discount rate
            </p>
          </div>

          {/* Step 3 */}
          <div className="text-center">
            <div className="brutal-card p-8 bg-hot-pink mb-6">
              <Clock className="w-12 h-12 text-background mx-auto" />
            </div>
            <h3 className="text-xl font-black uppercase mb-3">
              3. INSTANT FUNDING
            </h3>
            <p className="text-steel font-medium">
              Receive immediate payment minus the risk discount directly to your wallet
            </p>
          </div>

          {/* Step 4 */}
          <div className="text-center">
            <div className="brutal-card p-8 bg-electric-yellow mb-6">
              <Shield className="w-12 h-12 text-foreground mx-auto" />
            </div>
            <h3 className="text-xl font-black uppercase mb-3">
              4. SETTLEMENT TRACKING
            </h3>
            <p className="text-steel font-medium">
              Monitor payment progress via blockchain with SWIFT integration
            </p>
          </div>
        </div>

        {/* Large Visual Diagram */}
        <div className="brutal-card p-6 md:p-12 bg-surface">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 md:gap-8 items-center">
            {/* Your Company */}
            <div className="text-center">
              <div className="brutal-card p-6 bg-card mb-4">
                <h4 className="font-black text-lg uppercase mb-2">YOUR COMPANY</h4>
                <div className="text-3xl">🏢</div>
              </div>
              <div className="text-sm font-bold text-steel">Has $50k Invoice, Needs instant liquidity</div>
            </div>

            {/* Arrow 1 */}
            <div className="flex justify-center">
              <div className="brutal-card p-4 bg-electric-blue">
                <div className="text-background font-black text-sm uppercase">SELLS</div>
              </div>
            </div>

            {/* Platform */}
            <div className="text-center">
              <div className="brutal-card p-6 bg-electric-blue mb-4">
                <h4 className="font-black text-lg uppercase mb-2 text-background">
                  FACTORING PLATFORM
                </h4>
                <div className="text-3xl">⚡</div>
              </div>
              <div className="text-sm font-bold text-steel">Processes & Matches</div>
            </div>

            {/* Arrow 2 */}
            <div className="flex justify-center">
              <div className="brutal-card p-4 bg-neon-green">
                <div className="text-foreground font-black text-sm uppercase">PAYS</div>
              </div>
            </div>

            {/* Investor */}
            <div className="text-center">
              <div className="brutal-card p-6 bg-neon-green mb-4">
                <h4 className="font-black text-lg uppercase mb-2">INVESTOR</h4>
                <div className="text-3xl">💰</div>
              </div>
              <div className="text-sm font-bold text-steel">Pays $47.5k (5% discount), Receives $50k from original debitor</div>
            </div>
          </div>

          {/* Payment Flow */}
          <div className="mt-8 md:mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            <div className="brutal-card p-6 bg-card text-center">
              <div className="text-2xl font-black electric-text mb-2">$50,000</div>
              <div className="font-bold uppercase">Original Invoice Value</div>
            </div>
            
            <div className="brutal-card p-6 bg-electric-yellow text-center">
              <div className="text-2xl font-black text-foreground mb-2">- 5%</div>
              <div className="font-bold uppercase">Risk Discount</div>
            </div>
            
            <div className="brutal-card p-6 bg-neon-green text-center">
              <div className="text-2xl font-black text-foreground mb-2">$47,500</div>
              <div className="font-bold uppercase">Instant Payment</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FactoringVisual;