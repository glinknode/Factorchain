import { Upload, Users, CheckCircle, ArrowRight, Clock } from "lucide-react";

const InvoiceFlowVisual = () => {
  return (
    <div className="relative">
      {/* Main Flow Container */}
      <div className="brutal-card p-6 bg-card">
        <div className="space-y-4">
          {/* Title */}
          <div className="text-center">
            <h3 className="text-xl font-black uppercase">
              HOW IT WORKS
            </h3>
          </div>

          {/* 3 Column Flow */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Column 1: Upload */}
            <div className="brutal-card p-6 md:p-4 bg-electric-blue hover:scale-105 transition-transform">
              <div className="flex flex-col items-center text-center space-y-2">
                <Upload className="w-10 h-10 md:w-8 md:h-8 text-background" strokeWidth={3} />
                <div className="text-base md:text-sm font-black text-background uppercase">
                  Upload
                </div>
                <div className="text-sm md:text-xs text-background font-medium">
                  Submit Invoice
                </div>
              </div>
            </div>

            {/* Column 2: Match */}
            <div className="brutal-card p-6 md:p-4 bg-hot-pink hover:scale-105 transition-transform">
              <div className="flex flex-col items-center text-center space-y-2">
                <Users className="w-10 h-10 md:w-8 md:h-8 text-background" strokeWidth={3} />
                <div className="text-base md:text-sm font-black text-background uppercase">
                  Match
                </div>
                <div className="text-sm md:text-xs text-background font-medium">
                  Find Investors
                </div>
              </div>
            </div>

            {/* Column 3: Get Paid */}
            <div className="brutal-card p-6 md:p-4 bg-neon-green hover:scale-105 transition-transform">
              <div className="flex flex-col items-center text-center space-y-2">
                <CheckCircle className="w-10 h-10 md:w-8 md:h-8 text-foreground" strokeWidth={3} />
                <div className="text-base md:text-sm font-black text-foreground uppercase">
                  Get Paid
                </div>
                <div className="text-sm md:text-xs text-foreground font-medium">
                  Instant Cash
                </div>
              </div>
            </div>
          </div>

          {/* Simple stat */}
          <div className="text-center">
            <div className="text-2xl font-black electric-text">24 Hours</div>
            <div className="text-xs text-steel font-medium uppercase">Average Settlement</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoiceFlowVisual;
