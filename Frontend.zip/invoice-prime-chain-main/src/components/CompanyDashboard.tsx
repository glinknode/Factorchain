import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Clock, DollarSign, AlertTriangle, Upload, Shield, RefreshCw, Wallet } from "lucide-react";
import { useState } from "react";
import InvoiceUploadFlow from "./InvoiceUploadFlow";
import PartyRegistryStatus from "./PartyRegistryStatus";
import WalletConnectDialog from "./WalletConnectDialog";
import { approveMarketplaceForInvoice, isMarketplaceApprovedForInvoice } from "@/lib/blockchain";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/hooks/useWallet";
import { useInvoiceCache } from "@/contexts/InvoiceCacheContext";
import type { CompanyInvoice } from "@/lib/blockchain";

const CompanyDashboard = () => {
  const [isUploadFlowOpen, setIsUploadFlowOpen] = useState(false);
  const [showWalletDialog, setShowWalletDialog] = useState(false);
  const [approvingTokenId, setApprovingTokenId] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { toast } = useToast();
  const { isConnected, connectWallet } = useWallet();
  const { companyInvoices: invoices, isLoading, invalidateAndRefresh } = useInvoiceCache();

  const handleRefresh = async () => {
    try {
      setIsRefreshing(true);
      await invalidateAndRefresh();
      toast({
        title: "Refreshed",
        description: "All NFTs have been refreshed",
      });
    } catch (error) {
      console.error('Error refreshing invoices:', error);
      toast({
        title: "Error",
        description: "Failed to refresh invoices",
        variant: "destructive",
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleApproveMarketplace = async (tokenId: string) => {
    try {
      setApprovingTokenId(tokenId);
      toast({
        title: "Approval In Progress",
        description: "Please sign the transaction to approve the marketplace",
      });
      
      await approveMarketplaceForInvoice(tokenId);
      
      toast({
        title: "Approval Successful!",
        description: "The marketplace can now sell this invoice on your behalf",
      });
      
      // Refresh cache to update approval status
      await invalidateAndRefresh();
    } catch (error) {
      console.error('Error approving marketplace:', error);
      toast({
        title: "Approval Failed",
        description: "Failed to approve marketplace. Please try again.",
        variant: "destructive",
      });
    } finally {
      setApprovingTokenId(null);
    }
  };
  const getStatusIcon = (status: CompanyInvoice['status']) => {
    switch (status) {
      case 'settled': return <CheckCircle className="w-5 h-5" />;
      case 'funded': return <DollarSign className="w-5 h-5" />;
      case 'pending': return <Clock className="w-5 h-5" />;
    }
  };
  
  const getStatusColor = (status: CompanyInvoice['status']) => {
    switch (status) {
      case 'settled': return 'bg-neon-green text-foreground';
      case 'funded': return 'bg-electric-blue text-background';
      case 'pending': return 'bg-electric-yellow text-foreground';
    }
  };

  const totalFunded = invoices
    .filter(inv => inv.status === 'settled' || inv.status === 'funded')
    .reduce((sum, inv) => sum + inv.payoutAmount, 0);

  const pendingAmount = invoices
    .filter(inv => inv.status === 'pending')
    .reduce((sum, inv) => sum + inv.payoutAmount, 0);

  const avgDiscount = invoices.length > 0
    ? (invoices.reduce((sum, inv) => sum + inv.discountRate, 0) / invoices.length).toFixed(1)
    : '0.0';

  return (
    <div className="container mx-auto px-4 md:px-6 py-6 md:py-8">
      {/* Header */}
      <div className="mb-6 md:mb-8">
        <div className="brutal-card p-2 inline-block mb-3 md:mb-4 bg-card">
          <span className="text-xs md:text-sm font-black uppercase tracking-wider text-steel">
            COMPANY DASHBOARD
          </span>
        </div>
        <h1 className="text-2xl md:text-3xl lg:text-4xl font-black mb-2">
          YOUR <span className="electric-text">INVOICES</span>
        </h1>
        <p className="text-sm md:text-base lg:text-lg text-steel font-medium">
          Track your factored invoices and payout status
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
        <div className="brutal-card p-6 bg-neon-green">
          <div className="text-3xl font-black text-foreground">
            ${totalFunded.toLocaleString()}
          </div>
          <div className="text-sm font-bold text-foreground uppercase">
            TOTAL FUNDED
          </div>
        </div>
        
        <div className="brutal-card p-6 bg-electric-yellow">
          <div className="text-3xl font-black text-foreground">
            ${pendingAmount.toLocaleString()}
          </div>
          <div className="text-sm font-bold text-foreground uppercase">
            PENDING FUNDING
          </div>
        </div>
        
        <div className="brutal-card p-6 bg-electric-blue">
          <div className="text-3xl font-black text-background">
            {invoices.length}
          </div>
          <div className="text-sm font-bold text-background uppercase">
            TOTAL INVOICES
          </div>
        </div>
        
        <div className="brutal-card p-6 bg-hot-pink">
          <div className="text-3xl font-black text-background">
            {avgDiscount}%
          </div>
          <div className="text-sm font-bold text-background uppercase">
            AVG DISCOUNT
          </div>
        </div>
      </div>

      {/* PartyRegistry Status */}
      <PartyRegistryStatus />

      {/* Quick Actions */}
      <div className="mb-8">
        <Button 
          variant="brutal" 
          size="lg" 
          className="uppercase"
          onClick={() => {
            if (!isConnected) {
              setShowWalletDialog(true);
            } else {
              setIsUploadFlowOpen(true);
            }
          }}
        >
          <Upload className="mr-2" />
          UPLOAD NEW INVOICE
        </Button>
      </div>

      {/* Invoices List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black uppercase">INVOICE STATUS</h2>
          <Button 
            variant="brutal-outline" 
            size="sm" 
            className="uppercase"
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            REFRESH
          </Button>
        </div>
        
        {isLoading ? (
          <div className="brutal-card p-12 bg-card text-center">
            <div className="text-xl font-black text-steel">LOADING INVOICES...</div>
          </div>
        ) : !isConnected ? (
          <div className="brutal-card p-12 bg-card text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-electric-blue brutal-border flex items-center justify-center">
              <Wallet className="w-8 h-8 text-background" />
            </div>
            <div className="text-xl font-black text-foreground mb-2">
              WALLET NOT CONNECTED
            </div>
            <div className="text-steel mb-6">
              Connect your wallet to view your invoices
            </div>
            <Button variant="brutal" onClick={connectWallet}>
              CONNECT WALLET
            </Button>
          </div>
        ) : invoices.length === 0 ? (
          <div className="brutal-card p-12 bg-card text-center">
            <div className="text-xl font-black text-steel mb-2">NO INVOICES YET</div>
            <div className="text-steel">Upload your first invoice to get started</div>
          </div>
        ) : (
          invoices.map((invoice) => (
          <div key={invoice.tokenId} className="brutal-card p-4 md:p-6 bg-card">
            <div className="grid grid-cols-1 lg:grid-cols-6 gap-4 md:gap-6 items-center">
              {/* Invoice Info */}
              <div>
                <div className="font-black text-lg mb-1">{invoice.invoiceNumber}</div>
                <div className="text-sm text-steel font-medium">
                  Due: {invoice.dueDate}
                </div>
                <div className="text-xs text-steel font-medium">
                  {invoice.industry} • {invoice.currency}
                </div>
              </div>
              
              {/* Amounts */}
              <div className="text-center">
                <div className="text-2xl font-black text-foreground">
                  ${invoice.originalAmount.toLocaleString()}
                </div>
                <div className="text-sm font-bold text-steel uppercase">
                  ORIGINAL
                </div>
              </div>
              
              <div className="text-center">
                <div className="text-xl font-black text-danger">
                  -{invoice.discountRate}%
                </div>
                <div className="text-sm font-bold text-steel uppercase">
                  DISCOUNT
                </div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-black electric-text">
                  ${invoice.payoutAmount.toLocaleString()}
                </div>
                <div className="text-sm font-bold text-steel uppercase">
                  PAYOUT
                </div>
              </div>
              
              {/* Status & Timing */}
              <div>
                <Badge className={`brutal-border font-black mb-2 ${getStatusColor(invoice.status)}`}>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(invoice.status)}
                    {invoice.status.toUpperCase()}
                  </div>
                </Badge>
                {invoice.listed && (
                  <Badge className="brutal-border font-bold bg-hot-pink text-background">
                    LISTED
                  </Badge>
                )}
              </div>
              
              {/* Investor */}
              <div>
                <div className="font-bold text-foreground">{invoice.investor}</div>
                <div className="text-sm text-steel font-medium">Investor</div>
              </div>
            </div>
            
            {/* Marketplace Approval Status - Only show if listed and NOT approved */}
            {invoice.listed && !invoice.approvalStatus && (
              <div className="mt-4 pt-4 border-t-4 border-border">
                <div className="brutal-card p-4 bg-electric-yellow flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="w-5 h-5 text-foreground" />
                      <span className="font-black text-foreground">APPROVAL REQUIRED</span>
                    </div>
                    <p className="text-sm text-foreground font-medium">
                      Approve marketplace to enable sales
                    </p>
                  </div>
                  <Button
                    variant="brutal"
                    size="sm"
                    onClick={() => handleApproveMarketplace(invoice.tokenId)}
                    disabled={approvingTokenId === invoice.tokenId}
                    className="uppercase"
                  >
                    {approvingTokenId === invoice.tokenId ? "APPROVING..." : "APPROVE NOW"}
                  </Button>
                </div>
              </div>
            )}
            
            {/* Detailed Status for Funded/Settled */}
            {(invoice.status === 'funded' || invoice.status === 'settled') && (
              <div className="mt-6 pt-6 border-t-4 border-border">
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="brutal-card p-4 bg-neon-green">
                    <div className="font-black text-foreground mb-1">✓ INVESTOR MATCHED</div>
                    <div className="text-sm text-foreground">Funds committed</div>
                  </div>
                  
                  <div className={`brutal-card p-4 ${
                    invoice.status === 'settled' ? 'bg-neon-green' : 'bg-electric-yellow'
                  }`}>
                    <div className={`font-black mb-1 ${
                      invoice.status === 'settled' ? 'text-foreground' : 'text-foreground'
                    }`}>
                      {invoice.status === 'settled' ? '✓' : '⏳'} PAYOUT {invoice.status === 'settled' ? 'COMPLETED' : 'PROCESSING'}
                    </div>
                    <div className={`text-sm ${
                      invoice.status === 'settled' ? 'text-foreground' : 'text-foreground'
                    }`}>
                      {invoice.status === 'settled' ? 'Funds received' : 'Awaiting transfer'}
                    </div>
                  </div>
                  
                  <div className="brutal-card p-4 bg-concrete">
                    <div className="font-black text-steel mb-1">⏳ SETTLEMENT PENDING</div>
                    <div className="text-sm text-steel">Customer payment due</div>
                  </div>
                </div>
              </div>
            )}
          </div>
          ))
        )}
      </div>

      <InvoiceUploadFlow 
        isOpen={isUploadFlowOpen} 
        onClose={async () => {
          setIsUploadFlowOpen(false);
          await invalidateAndRefresh();
        }} 
      />

      <WalletConnectDialog
        isOpen={showWalletDialog}
        onClose={() => setShowWalletDialog(false)}
        title="Connect Your Wallet"
        description="You need to connect your wallet to upload and manage invoices"
      />
    </div>
  );
};

export default CompanyDashboard;