import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, FileText } from 'lucide-react';

interface InvoiceData {
  file: File | null;
  amount: string;
  issueDate: string;
  dueDate: string;
  paymentTarget: string;
  currency: string;
  description: string;
  companyName: string;
  industry: string;
  paymentMethod: 'swift' | 'stablecoin' | null;
}

interface InvoiceUploadStep1Props {
  data: InvoiceData;
  onDataChange: (data: InvoiceData) => void;
}

const InvoiceUploadStep1 = ({ data, onDataChange }: InvoiceUploadStep1Props) => {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles[0]) {
      onDataChange({ ...data, file: acceptedFiles[0] });
    }
  }, [data, onDataChange]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf']
    },
    maxFiles: 1
  });

  const handleFieldChange = (field: keyof InvoiceData, value: string) => {
    onDataChange({ ...data, [field]: value });
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8 p-6">
      {/* Left Side - File Upload */}
      <div>
        <h3 className="text-xl font-black uppercase mb-4">Upload Invoice PDF</h3>
        <Card className="p-8">
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
              isDragActive
                ? 'border-primary bg-primary/10'
                : data.file
                ? 'border-green-500 bg-green-50'
                : 'border-border hover:border-primary'
            }`}
          >
            <input {...getInputProps()} />
            {data.file ? (
              <div className="space-y-4">
                <FileText className="w-16 h-16 mx-auto text-green-600" />
                <div>
                  <p className="font-bold text-green-600">File uploaded successfully!</p>
                  <p className="text-sm text-steel">{data.file.name}</p>
                  <p className="text-xs text-steel">{(data.file.size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <Upload className="w-16 h-16 mx-auto text-steel" />
                <div>
                  <p className="text-lg font-bold">
                    {isDragActive ? 'Drop the PDF here...' : 'Drag & drop your invoice PDF'}
                  </p>
                  <p className="text-sm text-steel">or click to browse files</p>
                </div>
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Right Side - Metadata Form */}
      <div>
        <h3 className="text-xl font-black uppercase mb-4">Invoice Metadata</h3>
        <Card className="p-6 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="companyName" className="font-bold uppercase">Company Name *</Label>
              <Input
                id="companyName"
                value={data.companyName}
                onChange={(e) => handleFieldChange('companyName', e.target.value)}
                placeholder="Enter company name"
                className="mt-2"
              />
            </div>
            
            <div>
              <Label htmlFor="currency" className="font-bold uppercase">Currency</Label>
              <Select value={data.currency} onValueChange={(value) => handleFieldChange('currency', value)}>
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                  <SelectItem value="CHF">CHF</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="industry" className="font-bold uppercase">Industry *</Label>
            <Select value={data.industry} onValueChange={(value) => handleFieldChange('industry', value)}>
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="Select industry" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Healthcare">Healthcare</SelectItem>
                <SelectItem value="Manufacturing">Manufacturing</SelectItem>
                <SelectItem value="Technology">Technology</SelectItem>
                <SelectItem value="Retail">Retail</SelectItem>
                <SelectItem value="Construction">Construction</SelectItem>
                <SelectItem value="Transportation & Logistics">Transportation & Logistics</SelectItem>
                <SelectItem value="Professional Services">Professional Services</SelectItem>
                <SelectItem value="Hospitality">Hospitality</SelectItem>
                <SelectItem value="Agriculture">Agriculture</SelectItem>
                <SelectItem value="Energy & Utilities">Energy & Utilities</SelectItem>
                <SelectItem value="Financial Services">Financial Services</SelectItem>
                <SelectItem value="Real Estate">Real Estate</SelectItem>
                <SelectItem value="Telecommunications">Telecommunications</SelectItem>
                <SelectItem value="Education">Education</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="amount" className="font-bold uppercase">Invoice Amount *</Label>
            <Input
              id="amount"
              type="number"
              value={data.amount}
              onChange={(e) => handleFieldChange('amount', e.target.value)}
              placeholder="0.00"
              className="mt-2"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="issueDate" className="font-bold uppercase">Issue Date *</Label>
              <Input
                id="issueDate"
                type="date"
                value={data.issueDate}
                onChange={(e) => handleFieldChange('issueDate', e.target.value)}
                className="mt-2"
              />
            </div>
            
            <div>
              <Label htmlFor="dueDate" className="font-bold uppercase">Due Date *</Label>
              <Input
                id="dueDate"
                type="date"
                value={data.dueDate}
                onChange={(e) => handleFieldChange('dueDate', e.target.value)}
                className="mt-2"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="paymentTarget" className="font-bold uppercase">Payment Target</Label>
            <Select value={data.paymentTarget} onValueChange={(value) => handleFieldChange('paymentTarget', value)}>
              <SelectTrigger className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1 week">1 Week</SelectItem>
                <SelectItem value="2 weeks">2 Weeks</SelectItem>
                <SelectItem value="1 month">1 Month</SelectItem>
                <SelectItem value="2 months">2 Months</SelectItem>
                <SelectItem value="3 months">3 Months</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="description" className="font-bold uppercase">Description</Label>
            <Textarea
              id="description"
              value={data.description}
              onChange={(e) => handleFieldChange('description', e.target.value)}
              placeholder="Additional details about the invoice..."
              className="mt-2"
              rows={3}
            />
          </div>
        </Card>
      </div>
    </div>
  );
};

export default InvoiceUploadStep1;