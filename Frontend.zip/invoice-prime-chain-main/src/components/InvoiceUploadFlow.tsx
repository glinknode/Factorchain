import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ArrowRight, Upload, CreditCard, CheckCircle } from 'lucide-react';
import {
  Stepper,
  StepperIndicator,
  StepperItem,
  StepperNav,
  StepperTitle,
  StepperTrigger,
} from '@/components/ui/stepper';
import InvoiceUploadStep1 from './InvoiceUploadStep1';
import InvoiceUploadStep2 from './InvoiceUploadStep2';
import InvoiceUploadStep3 from './InvoiceUploadStep3';

interface InvoiceData {
  file: File | null;
  amount: string;
  issueDate: string;
  dueDate: string;
  paymentTarget: string;
  currency: string;
  description: string;
  companyName: string;
  industry: string;
  paymentMethod: 'swift' | 'stablecoin' | null;
}

interface InvoiceUploadFlowProps {
  isOpen: boolean;
  onClose: () => void;
}

const InvoiceUploadFlow = ({ isOpen, onClose }: InvoiceUploadFlowProps) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [invoiceData, setInvoiceData] = useState<InvoiceData>({
    file: null,
    amount: '',
    issueDate: '',
    dueDate: '',
    paymentTarget: '2 weeks',
    currency: 'USD',
    description: '',
    companyName: '',
    industry: '',
    paymentMethod: null,
  });

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleClose = () => {
    setCurrentStep(1);
    setInvoiceData({
      file: null,
      amount: '',
      issueDate: '',
      dueDate: '',
      paymentTarget: '2 weeks',
      currency: 'USD',
      description: '',
      companyName: '',
      industry: '',
      paymentMethod: null,
    });
    onClose();
  };

  const canProceedStep1 = invoiceData.file && invoiceData.amount && invoiceData.issueDate && invoiceData.dueDate && invoiceData.companyName && invoiceData.industry;
  const canProceedStep2 = invoiceData.paymentMethod;

  const steps = [
    { title: 'Upload & Details', icon: Upload },
    { title: 'Payment Method', icon: CreditCard },
    { title: 'Review & Confirm', icon: CheckCircle }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-6xl h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-2xl font-black uppercase text-center mb-6">
            INVOICE UPLOAD FLOW
          </DialogTitle>
          
          <div className="flex justify-center w-full mb-6">
            <Stepper value={currentStep} className="w-full max-w-2xl">
              <StepperNav className="gap-0 mb-8">
                {steps.map((step, index) => {
                  const StepIcon = step.icon;
                  const isCompleted = index + 1 < currentStep;
                  
                  return (
                     <StepperItem 
                      key={index} 
                      step={index + 1} 
                      className="relative flex-1 items-center mx-4"
                      completed={isCompleted}
                    >
                      {index < steps.length - 1 && (
                        <div className={`absolute top-1/2 left-1/2 w-20 h-1 bg-border border-t-2 border-b-2 border-black transform translate-x-full -translate-y-1/2 -z-10 ${isCompleted ? 'bg-lime-500 border-lime-700' : ''}`} />
                      )}
                      <StepperTrigger className="flex flex-col items-center justify-center gap-3 w-full p-4 bg-background border-2 border-black shadow-[3px_3px_0px_rgba(0,0,0,1)] data-[state=active]:bg-lime-200 data-[state=active]:border-lime-600 data-[state=completed]:bg-lime-300 data-[state=completed]:border-lime-700 font-black uppercase rounded-none">
                        <StepperIndicator className="bg-transparent border-none size-10 data-[state=completed]:bg-transparent data-[state=active]:bg-transparent">
                          <StepIcon className="size-5 text-black" />
                        </StepperIndicator>
                        <div className="flex flex-col items-center gap-1">
                          <StepperTitle className="text-center font-black uppercase text-xs tracking-wide group-data-[state=inactive]/step:text-muted-foreground">
                            {step.title}
                          </StepperTitle>
                        </div>
                      </StepperTrigger>
                    </StepperItem>
                  );
                })}
              </StepperNav>
            </Stepper>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto">
          {currentStep === 1 && (
            <InvoiceUploadStep1
              data={invoiceData}
              onDataChange={setInvoiceData}
            />
          )}
          {currentStep === 2 && (
            <InvoiceUploadStep2
              data={invoiceData}
              onDataChange={setInvoiceData}
            />
          )}
          {currentStep === 3 && (
            <InvoiceUploadStep3
              data={invoiceData}
              onComplete={handleClose}
            />
          )}
        </div>

        <div className="border-t pt-4 flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentStep === 1}
            className="uppercase font-bold border-2 border-black shadow-[2px_2px_0px_rgba(0,0,0,1)] hover:shadow-[1px_1px_0px_rgba(0,0,0,1)]"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>
          
          {currentStep < 3 ? (
            <Button
              onClick={handleNext}
              disabled={
                (currentStep === 1 && !canProceedStep1) ||
                (currentStep === 2 && !canProceedStep2)
              }
              className="uppercase font-bold bg-lime-400 hover:bg-lime-500 text-black border-2 border-black shadow-[2px_2px_0px_rgba(0,0,0,1)] hover:shadow-[1px_1px_0px_rgba(0,0,0,1)] disabled:bg-gray-200 disabled:text-gray-500"
            >
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : null}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default InvoiceUploadFlow;