import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Banknote, Coins, ArrowRight, Clock, Building, Hash } from 'lucide-react';

interface InvoiceData {
  file: File | null;
  amount: string;
  issueDate: string;
  dueDate: string;
  paymentTarget: string;
  currency: string;
  description: string;
  companyName: string;
  industry: string;
  paymentMethod: 'swift' | 'stablecoin' | null;
}

interface InvoiceUploadStep2Props {
  data: InvoiceData;
  onDataChange: (data: InvoiceData) => void;
}

const InvoiceUploadStep2 = ({ data, onDataChange }: InvoiceUploadStep2Props) => {
  const handlePaymentMethodSelect = (method: 'swift' | 'stablecoin') => {
    onDataChange({ ...data, paymentMethod: method });
  };

  // Mock SWIFT transaction data
  const mockSwiftTransaction = {
    messageType: 'TSIN.006.001 (Invoice Assignment Request)',
    referenceId: 'SWIFT-IAR-2024-001',
    timestamp: new Date().toISOString(),
    debtor: {
      name: data.companyName || 'Your Company',
      bic: 'YOURBANK',
      account: 'CH93 0076 2011 6238 5295 7'
    },
    creditor: {
      name: 'FACTORING PARTNER AG',
      bic: 'FACTOXX',
      account: 'CH91 0076 2011 6238 5295 8'
    },
    amount: data.amount,
    currency: data.currency,
    remittanceInfo: `Invoice factoring for INV-${Date.now()}`
  };

  return (
    <div className="p-6 space-y-8">
      <div className="text-center">
        <h3 className="text-2xl font-black uppercase mb-4">Choose Payment Method</h3>
        <p className="text-steel font-medium">Select how you want to receive your funds</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* SWIFT Option */}
        <Card className={`p-6 cursor-pointer transition-all hover:shadow-lg ${
          data.paymentMethod === 'swift' ? 'ring-2 ring-primary bg-primary/5' : ''
        }`}>
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-blue-100">
                  <Banknote className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-xl font-black">SWIFT Transfer</h4>
                  <p className="text-sm text-steel">Traditional banking network</p>
                </div>
              </div>
              <Badge variant="outline" className="font-bold">
                Traditional
              </Badge>
            </div>

            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-steel" />
                <span>Processing: 1-3 business days</span>
              </div>
              <div className="flex items-center gap-2">
                <Building className="w-4 h-4 text-steel" />
                <span>Standard banking infrastructure</span>
              </div>
            </div>

            <Button
              variant={data.paymentMethod === 'swift' ? 'default' : 'outline'}
              className="w-full font-bold uppercase"
              onClick={() => handlePaymentMethodSelect('swift')}
            >
              Select SWIFT
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </Card>

        {/* Stablecoin Option */}
        <Card className={`p-6 cursor-pointer transition-all hover:shadow-lg ${
          data.paymentMethod === 'stablecoin' ? 'ring-2 ring-primary bg-primary/5' : ''
        }`}>
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg bg-green-100">
                  <Coins className="w-8 h-8 text-green-600" />
                </div>
                <div>
                  <h4 className="text-xl font-black">Stablecoin</h4>
                  <p className="text-sm text-steel">Crypto-native solution</p>
                </div>
              </div>
              <Badge variant="outline" className="font-bold bg-green-50 text-green-700">
                Modern
              </Badge>
            </div>

            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-steel" />
                <span>Processing: Minutes to hours</span>
              </div>
              <div className="flex items-center gap-2">
                <Hash className="w-4 h-4 text-steel" />
                <span>Blockchain-based settlement</span>
              </div>
            </div>

            <Button
              variant={data.paymentMethod === 'stablecoin' ? 'default' : 'outline'}
              className="w-full font-bold uppercase"
              onClick={() => handlePaymentMethodSelect('stablecoin')}
            >
              Select Stablecoin
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </Card>
      </div>

      {/* SWIFT Transaction Preview */}
      {data.paymentMethod === 'swift' && (
        <div className="mt-8">
          <h4 className="text-lg font-black uppercase mb-4">SWIFT Transaction Preview</h4>
          <Card className="p-6 bg-blue-50 border-blue-200">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="font-bold text-blue-700 bg-blue-100">
                  {mockSwiftTransaction.messageType}
                </Badge>
                <span className="text-sm font-mono text-steel">
                  Ref: {mockSwiftTransaction.referenceId}
                </span>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h5 className="font-bold text-sm uppercase text-steel mb-2">From (Debtor)</h5>
                  <div className="space-y-1 text-sm">
                    <div className="font-medium">{mockSwiftTransaction.debtor.name}</div>
                    <div className="text-steel">BIC: {mockSwiftTransaction.debtor.bic}</div>
                    <div className="text-steel">Account: {mockSwiftTransaction.debtor.account}</div>
                  </div>
                </div>
                
                <div>
                  <h5 className="font-bold text-sm uppercase text-steel mb-2">To (Creditor)</h5>
                  <div className="space-y-1 text-sm">
                    <div className="font-medium">{mockSwiftTransaction.creditor.name}</div>
                    <div className="text-steel">BIC: {mockSwiftTransaction.creditor.bic}</div>
                    <div className="text-steel">Account: {mockSwiftTransaction.creditor.account}</div>
                  </div>
                </div>
              </div>
              
              <div className="pt-4 border-t border-blue-200">
                <div className="flex justify-between items-center">
                  <span className="font-bold">Amount:</span>
                  <span className="text-xl font-black text-blue-700">
                    {mockSwiftTransaction.amount} {mockSwiftTransaction.currency}
                  </span>
                </div>
                <div className="text-sm text-steel mt-2">
                  Remittance: {mockSwiftTransaction.remittanceInfo}
                </div>
              </div>
              
              <div className="text-xs text-steel">
                This is a mock representation of the SWIFT message that would be generated.
                Actual implementation would follow ISO 20022 standards.
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Stablecoin Info */}
      {data.paymentMethod === 'stablecoin' && (
        <div className="mt-8">
          <h4 className="text-lg font-black uppercase mb-4">Stablecoin Details</h4>
          <Card className="p-6 bg-green-50 border-green-200">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="font-bold">Settlement Network:</span>
                <Badge variant="outline" className="text-green-700 bg-green-100">Ethereum Mainnet</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-bold">Supported Tokens:</span>
                <span className="font-medium">USDC, USDT, DAI</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-bold">Gas Fees:</span>
                <span className="font-medium">Covered by platform</span>
              </div>
              <div className="text-sm text-steel mt-4">
                Detailed stablecoin configuration will be set up in the next step.
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default InvoiceUploadStep2;