import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Shield, Zap, TrendingUp, Upload, Wallet, CheckCircle, DollarSign, Clock } from "lucide-react";
import { useWallet } from "@/hooks/useWallet";
import { useNavigate } from "react-router-dom";

interface GetStartedDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

const GetStartedDialog = ({ isOpen, onClose }: GetStartedDialogProps) => {
  const { isConnected, address, isLoading, connectWallet, shortenAddress } = useWallet();
  const navigate = useNavigate();

  const handleNavigate = (path: string) => {
    onClose();
    navigate(path);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-background brutal-border-thick p-0">
        <DialogHeader className="brutal-border-thick bg-electric-blue p-6">
          <DialogTitle className="text-3xl md:text-4xl font-black uppercase text-background">
            WELCOME TO FACTORCHAIN
          </DialogTitle>
          <p className="text-background/90 font-bold mt-2">
            Your blockchain-powered invoice factoring platform
          </p>
        </DialogHeader>

        <div className="p-6 space-y-6">
          {/* Why Connect Wallet Section */}
          <div className="space-y-4">
            <h3 className="text-2xl font-black uppercase">
              WHY <span className="electric-text">CONNECT</span> YOUR WALLET?
            </h3>
            
            <div className="grid md:grid-cols-3 gap-4">
              <div className="brutal-card p-4 bg-card">
                <div className="brutal-border p-3 bg-neon-green inline-block mb-3">
                  <Shield className="w-6 h-6 text-foreground" />
                </div>
                <h4 className="font-black uppercase mb-2">SECURE IDENTITY</h4>
                <p className="text-sm text-steel">
                  Your wallet acts as your digital identity on the blockchain, ensuring all transactions are verifiable and secure
                </p>
              </div>

              <div className="brutal-card p-4 bg-card">
                <div className="brutal-border p-3 bg-electric-blue inline-block mb-3">
                  <Zap className="w-6 h-6 text-background" />
                </div>
                <h4 className="font-black uppercase mb-2">OWNERSHIP CONTROL</h4>
                <p className="text-sm text-steel">
                  Maintain full ownership of your invoice NFTs and investments without intermediaries
                </p>
              </div>

              <div className="brutal-card p-4 bg-card">
                <div className="brutal-border p-3 bg-hot-pink inline-block mb-3">
                  <Clock className="w-6 h-6 text-background" />
                </div>
                <h4 className="font-black uppercase mb-2">INSTANT TRANSACTIONS</h4>
                <p className="text-sm text-steel">
                  Execute peer-to-peer transactions directly on the blockchain for faster settlement
                </p>
              </div>
            </div>
          </div>

          {/* What You Can Do Section */}
          <div className="space-y-4">
            <h3 className="text-2xl font-black uppercase">
              WHAT YOU CAN <span className="neon-accent">DO</span>
            </h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              {/* Company Section */}
              <div className="brutal-card p-5 bg-electric-blue">
                <div className="flex items-center gap-3 mb-4">
                  <Upload className="w-7 h-7 text-background" />
                  <h4 className="text-xl font-black uppercase text-background">AS A COMPANY</h4>
                </div>
                <ul className="space-y-2 text-background">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span className="font-medium">Upload invoices and get instant funding (minus discount)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span className="font-medium">Track settlement status via blockchain</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span className="font-medium">Improve cash flow without taking on debt</span>
                  </li>
                </ul>
                {isConnected && (
                  <Button 
                    variant="brutal-outline" 
                    className="w-full mt-4 bg-background text-electric-blue hover:bg-background/90"
                    onClick={() => handleNavigate('/company')}
                  >
                    GO TO COMPANY DASHBOARD
                  </Button>
                )}
              </div>

              {/* Investor Section */}
              <div className="brutal-card p-5 bg-neon-green">
                <div className="flex items-center gap-3 mb-4">
                  <TrendingUp className="w-7 h-7 text-foreground" />
                  <h4 className="text-xl font-black uppercase text-foreground">AS AN INVESTOR</h4>
                </div>
                <ul className="space-y-2 text-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span className="font-medium">Browse verified invoices from trusted companies</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span className="font-medium">Purchase invoice NFTs with USDC stablecoin</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <span className="font-medium">Earn returns when invoices are settled</span>
                  </li>
                </ul>
                {isConnected && (
                  <Button 
                    variant="brutal-outline" 
                    className="w-full mt-4 bg-background text-neon-green hover:bg-background/90"
                    onClick={() => handleNavigate('/market')}
                  >
                    BROWSE MARKETPLACE
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Wallet Connection Section */}
          <div className="brutal-card p-6 bg-surface">
            {isConnected ? (
              <div className="text-center space-y-4">
                <div className="brutal-border p-4 bg-neon-green inline-block">
                  <Wallet className="w-12 h-12 text-foreground" />
                </div>
                <div>
                  <h4 className="text-2xl font-black uppercase mb-2">
                    ✓ WALLET CONNECTED
                  </h4>
                  <div className="brutal-card px-4 py-2 bg-electric-blue inline-block">
                    <span className="font-black text-background">{shortenAddress(address!)}</span>
                  </div>
                </div>
                <p className="text-steel font-medium max-w-md mx-auto">
                  You're all set! Choose your path and start using FactorChain
                </p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
                  <Button 
                    variant="brutal" 
                    className="uppercase"
                    onClick={() => handleNavigate('/company')}
                  >
                    <Upload className="mr-2" />
                    COMPANY DASHBOARD
                  </Button>
                  <Button 
                    variant="brutal-secondary" 
                    className="uppercase"
                    onClick={() => handleNavigate('/market')}
                  >
                    <DollarSign className="mr-2" />
                    BROWSE MARKET
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center space-y-4">
                <div className="brutal-border p-4 bg-electric-yellow inline-block">
                  <Wallet className="w-12 h-12 text-foreground" />
                </div>
                <div>
                  <h4 className="text-2xl font-black uppercase mb-2">
                    CONNECT YOUR WALLET
                  </h4>
                  <p className="text-steel font-medium max-w-md mx-auto">
                    Connect your Web3 wallet to start factoring invoices or investing in the marketplace
                  </p>
                </div>
                <Button 
                  variant="brutal" 
                  size="lg"
                  className="uppercase"
                  onClick={connectWallet}
                  disabled={isLoading}
                >
                  <Wallet className="mr-2" />
                  {isLoading ? "CONNECTING..." : "CONNECT WALLET"}
                </Button>
                <p className="text-xs text-steel">
                  Supported wallets: MetaMask, WalletConnect, Coinbase Wallet
                </p>
              </div>
            )}
          </div>

          {/* How It Works */}
          <div className="brutal-card p-5 bg-card">
            <h4 className="text-xl font-black uppercase mb-4 text-center">
              HOW IT <span className="electric-text">WORKS</span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="brutal-card p-3 bg-electric-blue inline-block mb-2">
                  <span className="text-2xl font-black text-background">1</span>
                </div>
                <p className="font-bold text-sm">CONNECT WALLET</p>
                <p className="text-xs text-steel">Link your Web3 wallet</p>
              </div>
              <div className="text-center">
                <div className="brutal-card p-3 bg-hot-pink inline-block mb-2">
                  <span className="text-2xl font-black text-background">2</span>
                </div>
                <p className="font-bold text-sm">CHOOSE ROLE</p>
                <p className="text-xs text-steel">Company or Investor</p>
              </div>
              <div className="text-center">
                <div className="brutal-card p-3 bg-neon-green inline-block mb-2">
                  <span className="text-2xl font-black text-foreground">3</span>
                </div>
                <p className="font-bold text-sm">START TRADING</p>
                <p className="text-xs text-steel">Upload or invest</p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default GetStartedDialog;
