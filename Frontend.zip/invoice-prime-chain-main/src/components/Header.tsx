import { Button } from "@/components/ui/button";
import { Menu, X, Zap, Wallet } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useWallet } from "@/hooks/useWallet";
import GetStartedDialog from "./GetStartedDialog";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isGetStartedOpen, setIsGetStartedOpen] = useState(false);
  const location = useLocation();
  const { isConnected, address, isLoading, connectWallet, disconnectWallet, shortenAddress } = useWallet();

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="brutal-border-thick bg-background sticky top-0 z-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center gap-4 md:gap-8 h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 md:gap-3">
            <div className="brutal-card p-2 md:p-3 bg-electric-blue">
              <Zap className="w-5 h-5 md:w-6 md:h-6 text-background" />
            </div>
            <div className="hidden sm:block">
              <div className="text-lg md:text-2xl font-black uppercase electric-text">FACTORCHAIN</div>
              <div className="text-xs font-bold text-steel uppercase tracking-wide hidden md:block">BLOCKCHAIN FACTORING</div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link
              to="/company"
              className={`font-bold uppercase tracking-wide ${
                isActive("/company") ? "text-primary" : "text-foreground hover:text-primary"
              }`}
            >
              COMPANY DASHBOARD
            </Link>
            <Link
              to="/investor"
              className={`font-bold uppercase tracking-wide ${
                isActive("/investor") ? "text-primary" : "text-foreground hover:text-primary"
              }`}
            >
              INVESTOR DASHBOARD
            </Link>
            <Link
              to="/market"
              className={`font-bold uppercase tracking-wide ${
                isActive("/market") ? "text-primary" : "text-foreground hover:text-primary"
              }`}
            >
              MARKET
            </Link>
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center gap-4 ml-auto">
            {isConnected ? (
              <div className="flex items-center gap-3">
                <div className="brutal-card px-3 py-2 bg-electric-blue flex items-center gap-2 h-9">
                  <Wallet className="w-4 h-4 text-background" />
                  <span className="font-bold text-sm uppercase text-background">{shortenAddress(address!)}</span>
                </div>
                <Button variant="brutal-outline" size="sm" className="uppercase" onClick={disconnectWallet}>
                  DISCONNECT
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-4">
                <Button
                  variant="brutal-outline"
                  size="sm"
                  className="uppercase"
                  onClick={connectWallet}
                  disabled={isLoading}
                >
                  <Wallet className="w-4 h-4 mr-2" />
                  {isLoading ? "CONNECTING..." : "CONNECT"}
                </Button>
                <Button 
                  variant="brutal" 
                  size="sm" 
                  className="uppercase"
                  onClick={() => setIsGetStartedOpen(true)}
                >
                  GET STARTED
                </Button>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <Button variant="brutal-outline" size="icon" className="md:hidden ml-auto" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden brutal-card mt-4 p-6 bg-card">
            <nav className="flex flex-col gap-4 mb-6">
              <Link
                to="/company"
                className={`font-bold uppercase tracking-wide py-2 ${
                  isActive("/company") ? "text-primary" : "text-foreground hover:text-primary"
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                COMPANY DASHBOARD
              </Link>
              <Link
                to="/investor"
                className={`font-bold uppercase tracking-wide py-2 ${
                  isActive("/investor") ? "text-primary" : "text-foreground hover:text-primary"
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                INVESTOR DASHBOARD
              </Link>
              <Link
                to="/market"
                className={`font-bold uppercase tracking-wide py-2 ${
                  isActive("/market") ? "text-primary" : "text-foreground hover:text-primary"
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                MARKET
              </Link>
            </nav>

            <div className="flex flex-col gap-3">
              {isConnected ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 p-3 brutal-card bg-electric-blue">
                    <Wallet className="w-4 h-4 text-background" />
                    <span className="font-bold text-sm uppercase text-background">{shortenAddress(address!)}</span>
                  </div>
                  <Button variant="brutal-outline" className="uppercase w-full" onClick={disconnectWallet}>
                    DISCONNECT
                  </Button>
                </div>
              ) : (
                <Button variant="brutal-outline" className="uppercase" onClick={connectWallet} disabled={isLoading}>
                  <Wallet className="w-4 h-4 mr-2" />
                  {isLoading ? "CONNECTING..." : "CONNECT"}
                </Button>
              )}
              <Button 
                variant="brutal" 
                className="uppercase"
                onClick={() => setIsGetStartedOpen(true)}
              >
                GET STARTED
              </Button>
            </div>
          </div>
        )}
      </div>

      <GetStartedDialog 
        isOpen={isGetStartedOpen} 
        onClose={() => setIsGetStartedOpen(false)} 
      />
    </header>
  );
};

export default Header;
