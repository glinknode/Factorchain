// Re-export the hook from the context for backward compatibility
export { useWallet } from '@/contexts/WalletContext';