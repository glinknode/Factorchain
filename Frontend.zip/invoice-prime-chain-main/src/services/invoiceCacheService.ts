import { createViemPublicClient } from '@/lib/blockchain';
import InvoiceNFTAbi from '@/abi/InvoiceNFT.json';
import { CONTRACT_ADDRESSES, CONSTANTS } from '@/contracts/constants';
import type { CompanyInvoice, InvestorInvoice, MarketInvoice } from '@/lib/blockchain';

// Raw invoice data from blockchain
interface RawInvoiceData {
  tokenId: string;
  owner: string;
  kreditor: string;
  uploader: string;
  amount: bigint;
  currency: string;
  dueDate: bigint;
  debtor: string;
  settled: boolean;
  discountBps: number;
  riskBps: number;
  listed: boolean;
  industry: string;
  netPrice: bigint;
  approvalStatus: boolean;
}

// Helper to convert bytes3 currency to string
function bytes3ToStr(bytes3: string): string {
  try {
    const hex = bytes3.replace('0x', '');
    let str = '';
    for (let i = 0; i < hex.length; i += 2) {
      const charCode = parseInt(hex.substr(i, 2), 16);
      if (charCode !== 0) str += String.fromCharCode(charCode);
    }
    return str || 'USD';
  } catch {
    return 'USD';
  }
}

// Helper: Find the highest minted token ID using binary search
async function findMaxTokenId(publicClient: any): Promise<number> {
  try {
    await (publicClient as any).readContract({
      address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
      abi: InvoiceNFTAbi,
      functionName: 'ownerOf',
      args: [BigInt(1)],
    });
  } catch {
    return 0;
  }

  let low = 1;
  let high = 1000;
  
  while (true) {
    try {
      await (publicClient as any).readContract({
        address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
        abi: InvoiceNFTAbi,
        functionName: 'ownerOf',
        args: [BigInt(high)],
      });
      low = high;
      high *= 2;
    } catch {
      break;
    }
  }

  while (low < high) {
    const mid = Math.floor((low + high + 1) / 2);
    try {
      await (publicClient as any).readContract({
        address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
        abi: InvoiceNFTAbi,
        functionName: 'ownerOf',
        args: [BigInt(mid)],
      });
      low = mid;
    } catch {
      high = mid - 1;
    }
  }

  return low;
}

// Helper to determine credit rating based on risk
function getRiskBasedRating(riskBps: number): 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B' {
  if (riskBps < 200) return 'AAA';
  if (riskBps < 400) return 'AA';
  if (riskBps < 600) return 'A';
  if (riskBps < 800) return 'BBB';
  if (riskBps < 1000) return 'BB';
  return 'B';
}

// Helper to determine risk level
function getRiskLevel(riskBps: number): 'low' | 'medium' | 'high' {
  if (riskBps < 500) return 'low';
  if (riskBps < 1000) return 'medium';
  return 'high';
}

type CacheListener = () => void;

class InvoiceCacheService {
  private static instance: InvoiceCacheService;
  private cache: RawInvoiceData[] = [];
  private lastFetch: number = 0;
  private isFetching: boolean = false;
  private listeners: Set<CacheListener> = new Set();
  private currentUserAddress: string | null = null;

  private constructor() {}

  static getInstance(): InvoiceCacheService {
    if (!InvoiceCacheService.instance) {
      InvoiceCacheService.instance = new InvoiceCacheService();
    }
    return InvoiceCacheService.instance;
  }

  subscribe(listener: CacheListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners() {
    this.listeners.forEach(listener => listener());
  }

  async fetchAllInvoices(forceRefresh: boolean = false): Promise<void> {
    // Check if we need to refresh
    if (!forceRefresh && this.cache.length > 0) {
      return;
    }

    // Prevent concurrent fetches
    if (this.isFetching) {
      return;
    }

    try {
      this.isFetching = true;

      const publicClient = await createViemPublicClient();
      const maxTokenId = await findMaxTokenId(publicClient);

      if (maxTokenId === 0) {
        this.cache = [];
        this.lastFetch = Date.now();
        this.notifyListeners();
        return;
      }

      const allInvoices: RawInvoiceData[] = [];
      const batchSize = 10;

      for (let tokenId = 1; tokenId <= maxTokenId; tokenId += batchSize) {
        const batchPromises = [];

        for (let i = 0; i < batchSize && tokenId + i <= maxTokenId; i++) {
          const currentTokenId = tokenId + i;
          batchPromises.push(
            (async () => {
              try {
                const [owner, metaData, invoiceData, pricingData, industry] = await Promise.all([
                  (publicClient as any).readContract({
                    address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                    abi: InvoiceNFTAbi,
                    functionName: 'ownerOf',
                    args: [BigInt(currentTokenId)],
                  }),
                  (publicClient as any).readContract({
                    address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                    abi: InvoiceNFTAbi,
                    functionName: 'invoiceMeta',
                    args: [BigInt(currentTokenId)],
                  }),
                  (publicClient as any).readContract({
                    address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                    abi: InvoiceNFTAbi,
                    functionName: 'invoices',
                    args: [BigInt(currentTokenId)],
                  }),
                  (publicClient as any).readContract({
                    address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                    abi: InvoiceNFTAbi,
                    functionName: 'getPricing',
                    args: [BigInt(currentTokenId)],
                  }),
                  (publicClient as any).readContract({
                    address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                    abi: InvoiceNFTAbi,
                    functionName: 'industryOf',
                    args: [BigInt(currentTokenId)],
                  }),
                ]);

                const listed = metaData[4] as boolean;
                
                // Fetch approval status only for listed invoices
                let approvalStatus = false;
                if (listed) {
                  try {
                    const approvedAddress = await (publicClient as any).readContract({
                      address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                      abi: InvoiceNFTAbi,
                      functionName: 'getApproved',
                      args: [BigInt(currentTokenId)],
                    }) as string;
                    approvalStatus = approvedAddress.toLowerCase() === CONTRACT_ADDRESSES.MKT.toLowerCase();
                  } catch (error) {
                    console.error(`Error fetching approval status for token ${currentTokenId}:`, error);
                  }
                }

                return {
                  tokenId: currentTokenId.toString(),
                  owner: (owner as string).toLowerCase(),
                  kreditor: (metaData[0] as string).toLowerCase(),
                  uploader: (metaData[1] as string).toLowerCase(),
                  amount: invoiceData[0] as bigint,
                  currency: bytes3ToStr(invoiceData[1] as string),
                  dueDate: invoiceData[2] as bigint,
                  debtor: invoiceData[3] as string,
                  settled: invoiceData[6] as boolean,
                  discountBps: metaData[2] as number,
                  riskBps: metaData[3] as number,
                  listed,
                  industry: (industry as string) || 'General',
                  netPrice: pricingData[3] as bigint,
                  approvalStatus,
                } as RawInvoiceData;
              } catch (error) {
                console.error(`Error fetching invoice ${currentTokenId}:`, error);
                return null;
              }
            })()
          );
        }

        const batchResults = await Promise.all(batchPromises);
        batchResults.forEach(result => {
          if (result) allInvoices.push(result);
        });
      }

      this.cache = allInvoices;
      this.lastFetch = Date.now();
      this.notifyListeners();
    } finally {
      this.isFetching = false;
    }
  }

  getCompanyInvoices(userAddress: string): CompanyInvoice[] {
    return this.cache
      .filter(invoice => invoice.kreditor === userAddress.toLowerCase())
      .map(invoice => {
        const originalAmount = Number(invoice.amount) / CONSTANTS.MICRO_1;
        const payoutAmount = Number(invoice.netPrice) / CONSTANTS.MICRO_1;
        const dueDateStr = new Date(Number(invoice.dueDate) * 1000).toISOString().split('T')[0];

        let status: 'pending' | 'funded' | 'settled';
        if (invoice.settled) {
          status = 'settled';
        } else if (invoice.owner !== invoice.kreditor) {
          status = 'funded';
        } else {
          status = 'pending';
        }

        return {
          tokenId: invoice.tokenId,
          invoiceNumber: `INV-${invoice.tokenId.padStart(6, '0')}`,
          originalAmount,
          discountRate: invoice.discountBps / 100,
          payoutAmount,
          status,
          createdDate: dueDateStr,
          dueDate: dueDateStr,
          currentOwner: invoice.owner,
          investor: invoice.owner !== invoice.kreditor 
            ? `${invoice.owner.slice(0, 6)}...${invoice.owner.slice(-4)}` 
            : 'PENDING MATCH',
          industry: invoice.industry,
          currency: invoice.currency,
          listed: invoice.listed,
          settled: invoice.settled,
          approvalStatus: invoice.approvalStatus,
        };
      });
  }

  getInvestorInvoices(userAddress: string): InvestorInvoice[] {
    return this.cache
      .filter(invoice => 
        invoice.owner === userAddress.toLowerCase() && 
        invoice.kreditor !== userAddress.toLowerCase()
      )
      .map(invoice => {
        const originalAmount = Number(invoice.amount) / CONSTANTS.MICRO_1;
        const investmentAmount = Number(invoice.netPrice) / CONSTANTS.MICRO_1;
        const dueDateMs = Number(invoice.dueDate) * 1000;
        const now = Date.now();
        const daysUntilDue = Math.max(0, Math.ceil((dueDateMs - now) / (1000 * 60 * 60 * 24)));
        const dueDateStr = new Date(dueDateMs).toISOString().split('T')[0];

        return {
          tokenId: invoice.tokenId,
          invoiceNumber: `INV-${invoice.tokenId.padStart(6, '0')}`,
          company: `${invoice.kreditor.slice(0, 6)}...${invoice.kreditor.slice(-4)}`,
          industry: invoice.industry,
          investmentAmount,
          expectedReturn: originalAmount,
          status: invoice.settled ? 'settled' : 'active',
          purchaseDate: dueDateStr,
          dueDate: dueDateStr,
          daysUntilDue,
          currency: invoice.currency,
          settled: invoice.settled,
          kreditor: invoice.kreditor,
          discountRate: invoice.discountBps / 100,
        };
      });
  }

  getMarketInvoices(userAddress?: string): MarketInvoice[] {
    return this.cache
      .filter(invoice => 
        invoice.listed && 
        !invoice.settled && 
        (!userAddress || invoice.owner !== userAddress.toLowerCase())
      )
      .map(invoice => {
        const originalAmount = Number(invoice.amount) / CONSTANTS.MICRO_1;
        const investmentAmount = Number(invoice.netPrice) / CONSTANTS.MICRO_1;
        const dueDateMs = Number(invoice.dueDate) * 1000;
        const now = Date.now();
        const daysUntilDue = Math.max(0, Math.ceil((dueDateMs - now) / (1000 * 60 * 60 * 24)));
        const dueDateStr = new Date(dueDateMs).toISOString().split('T')[0];

        return {
          tokenId: invoice.tokenId,
          invoiceNumber: `INV-${invoice.tokenId.padStart(6, '0')}`,
          company: `TOKEN #${invoice.tokenId}`,
          industry: invoice.industry,
          originalAmount,
          discountRate: invoice.discountBps / 100,
          investmentAmount,
          expectedReturn: originalAmount,
          dueDate: dueDateStr,
          daysUntilDue,
          creditRating: getRiskBasedRating(invoice.riskBps),
          riskLevel: getRiskLevel(invoice.riskBps),
          description: `Invoice NFT ${invoice.tokenId} - ${invoice.currency} ${originalAmount.toLocaleString()}`,
          owner: invoice.owner,
          debtor: invoice.debtor,
          settled: false,
          currency: invoice.currency,
          approvalStatus: invoice.approvalStatus,
        };
      });
  }

  invalidateCache() {
    this.cache = [];
    this.lastFetch = 0;
  }

  isCacheValid(): boolean {
    return this.cache.length > 0 && this.lastFetch > 0;
  }

  getIsFetching(): boolean {
    return this.isFetching;
  }

  setCurrentUserAddress(userAddress: string | null): void {
    this.currentUserAddress = userAddress;
    this.notifyListeners();
  }

  getCurrentUserAddress(): string | null {
    return this.currentUserAddress;
  }
}

export default InvoiceCacheService.getInstance();
