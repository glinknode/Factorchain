import { checkIfAddressTrusted, getPartyInfo, type Party } from '@/lib/blockchain';

export type PartyStatus = {
  isRegistered: boolean;
  isTrusted: boolean;
  party: Party | null;
  lastUpdated: number;
};

type Listener = (status: PartyStatus) => void;

/**
 * Singleton service to manage Party Registry state with caching and polling
 * - Caches registry data for verified parties (5 min)
 * - Polls every 5s for pending verifications
 * - Notifies listeners on state changes
 */
class PartyRegistryService {
  private cache: Map<string, PartyStatus> = new Map();
  private listeners: Set<Listener> = new Set();
  private pollingTimers: Map<string, NodeJS.Timeout> = new Map();
  
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes for verified parties
  private readonly POLL_INTERVAL = 5 * 1000; // 5 seconds for pending verifications

  /**
   * Subscribe to status changes for a specific address
   */
  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  /**
   * Notify all listeners of status change
   */
  private notify(status: PartyStatus) {
    this.listeners.forEach(listener => listener(status));
  }

  /**
   * Get cached status if available and not expired
   */
  private getCached(address: string): PartyStatus | null {
    const cached = this.cache.get(address.toLowerCase());
    if (!cached) return null;

    const age = Date.now() - cached.lastUpdated;
    
    // If trusted, cache is valid for CACHE_DURATION
    if (cached.isTrusted && age < this.CACHE_DURATION) {
      return cached;
    }

    // If not trusted (pending), don't use old cache
    return null;
  }

  /**
   * Fetch fresh status from blockchain
   */
  private async fetchFromBlockchain(address: string): Promise<PartyStatus> {
    try {
      const party = await getPartyInfo(address);
      const isTrusted = party?.isTrusted ?? false;
      
      const status: PartyStatus = {
        isRegistered: party !== null,
        isTrusted,
        party,
        lastUpdated: Date.now(),
      };

      // Cache the result
      this.cache.set(address.toLowerCase(), status);
      
      return status;
    } catch (error) {
      console.error('Error fetching party status:', error);
      
      // Return unregistered status on error
      const errorStatus: PartyStatus = {
        isRegistered: false,
        isTrusted: false,
        party: null,
        lastUpdated: Date.now(),
      };
      
      return errorStatus;
    }
  }

  /**
   * Start polling for pending verifications
   */
  private startPolling(address: string) {
    // Don't start if already polling
    if (this.pollingTimers.has(address.toLowerCase())) return;

    const timer = setInterval(async () => {
      const status = await this.fetchFromBlockchain(address);
      this.notify(status);

      // Stop polling if now trusted or unregistered
      if (status.isTrusted || !status.isRegistered) {
        this.stopPolling(address);
      }
    }, this.POLL_INTERVAL);

    this.pollingTimers.set(address.toLowerCase(), timer);
  }

  /**
   * Stop polling for an address
   */
  private stopPolling(address: string) {
    const timer = this.pollingTimers.get(address.toLowerCase());
    if (timer) {
      clearInterval(timer);
      this.pollingTimers.delete(address.toLowerCase());
    }
  }

  /**
   * Get party status with smart caching and polling
   */
  async getStatus(address: string, forceRefresh = false): Promise<PartyStatus> {
    if (!address) {
      return {
        isRegistered: false,
        isTrusted: false,
        party: null,
        lastUpdated: Date.now(),
      };
    }

    // Check cache first unless forcing refresh
    if (!forceRefresh) {
      const cached = this.getCached(address);
      if (cached) return cached;
    }

    // Fetch fresh data
    const status = await this.fetchFromBlockchain(address);

    // Start polling if registered but not trusted (pending verification)
    if (status.isRegistered && !status.isTrusted) {
      this.startPolling(address);
    } else {
      // Stop polling if trusted or unregistered
      this.stopPolling(address);
    }

    // Notify listeners
    this.notify(status);

    return status;
  }

  /**
   * Invalidate cache and refresh status
   */
  async invalidateAndRefresh(address: string): Promise<PartyStatus> {
    this.cache.delete(address.toLowerCase());
    return this.getStatus(address, true);
  }

  /**
   * Clear all cache and stop all polling (for wallet disconnect)
   */
  clearAll() {
    this.cache.clear();
    this.pollingTimers.forEach(timer => clearInterval(timer));
    this.pollingTimers.clear();
  }
}

// Export singleton instance
export const partyRegistryService = new PartyRegistryService();
