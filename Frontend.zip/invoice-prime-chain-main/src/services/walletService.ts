const WALLET_DISCONNECT_KEY = 'wallet_manually_disconnected';
const SEPOLIA_CHAIN_ID = '0xaa36a7';

// Extend Window interface for MetaMask
declare global {
  interface Window {
    ethereum?: any;
  }
}

export type WalletStatus = {
  isConnected: boolean;
  address: string | null;
  chainId: string | null;
  error: string | null;
};

type StatusListener = (status: WalletStatus) => void;

/**
 * Singleton service to manage wallet connection state
 * - Handles MetaMask detection and connection
 * - Manages network switching to Sepolia
 * - Provides event listeners for account/chain changes
 * - Maintains disconnect flag in session storage
 */
class WalletService {
  private listeners: Set<StatusListener> = new Set();
  private accountsChangeHandler: ((accounts: string[]) => void) | null = null;
  private chainChangeHandler: (() => void) | null = null;

  /**
   * Check if MetaMask is installed
   */
  isMetaMaskInstalled(): boolean {
    return typeof window.ethereum !== 'undefined';
  }

  /**
   * Get the manual disconnect flag from session storage
   */
  getDisconnectFlag(): boolean {
    return sessionStorage.getItem(WALLET_DISCONNECT_KEY) === 'true';
  }

  /**
   * Set the manual disconnect flag in session storage
   */
  setDisconnectFlag(value: boolean): void {
    if (value) {
      sessionStorage.setItem(WALLET_DISCONNECT_KEY, 'true');
    } else {
      sessionStorage.removeItem(WALLET_DISCONNECT_KEY);
    }
  }

  /**
   * Subscribe to wallet status changes
   */
  subscribe(listener: StatusListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  /**
   * Notify all listeners of status change
   */
  private notify(status: WalletStatus): void {
    this.listeners.forEach(listener => listener(status));
  }

  /**
   * Get current connected accounts
   */
  async getConnectedAccounts(): Promise<string[]> {
    if (!this.isMetaMaskInstalled()) {
      return [];
    }

    try {
      const accounts = await window.ethereum.request({ method: 'eth_accounts' });
      return accounts || [];
    } catch (error) {
      console.error('Error getting connected accounts:', error);
      return [];
    }
  }

  /**
   * Get current chain ID
   */
  async getCurrentChainId(): Promise<string | null> {
    if (!this.isMetaMaskInstalled()) {
      return null;
    }

    try {
      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      return chainId;
    } catch (error) {
      console.error('Error getting chain ID:', error);
      return null;
    }
  }

  /**
   * Check if currently connected to Sepolia
   */
  async isConnectedToSepolia(): Promise<boolean> {
    const chainId = await this.getCurrentChainId();
    return chainId === SEPOLIA_CHAIN_ID;
  }

  /**
   * Switch to Sepolia network
   */
  async switchToSepolia(): Promise<void> {
    if (!this.isMetaMaskInstalled()) {
      throw new Error('MetaMask is not installed');
    }

    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: SEPOLIA_CHAIN_ID }],
      });
    } catch (switchError: any) {
      // If Sepolia is not added (error code 4902), add it
      if (switchError.code === 4902) {
        await this.addSepoliaNetwork();
      } else {
        throw switchError;
      }
    }
  }

  /**
   * Add Sepolia network to MetaMask
   */
  async addSepoliaNetwork(): Promise<void> {
    if (!this.isMetaMaskInstalled()) {
      throw new Error('MetaMask is not installed');
    }

    await window.ethereum.request({
      method: 'wallet_addEthereumChain',
      params: [{
        chainId: SEPOLIA_CHAIN_ID,
        chainName: 'Sepolia Test Network',
        nativeCurrency: {
          name: 'Sepolia ETH',
          symbol: 'SepoliaETH',
          decimals: 18,
        },
        rpcUrls: ['https://sepolia.infura.io/v3/'],
        blockExplorerUrls: ['https://sepolia.etherscan.io'],
      }],
    });
  }

  /**
   * Request wallet connection with permissions
   */
  async connect(): Promise<WalletStatus> {
    // Clear disconnect flag
    this.setDisconnectFlag(false);

    if (!this.isMetaMaskInstalled()) {
      const status: WalletStatus = {
        isConnected: false,
        address: null,
        chainId: null,
        error: 'MetaMask is not installed',
      };
      this.notify(status);
      return status;
    }

    try {
      // Request permissions first
      await window.ethereum.request({
        method: 'wallet_requestPermissions',
        params: [{ eth_accounts: {} }],
      });

      // Then request accounts
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts',
      });

      if (accounts.length === 0) {
        const status: WalletStatus = {
          isConnected: false,
          address: null,
          chainId: null,
          error: 'No accounts found',
        };
        this.notify(status);
        return status;
      }

      // Check network
      const chainId = await this.getCurrentChainId();
      
      if (chainId !== SEPOLIA_CHAIN_ID) {
        // Try to switch to Sepolia
        await this.switchToSepolia();
      }

      const status: WalletStatus = {
        isConnected: true,
        address: accounts[0],
        chainId: SEPOLIA_CHAIN_ID,
        error: null,
      };

      this.notify(status);
      return status;
    } catch (error: any) {
      const status: WalletStatus = {
        isConnected: false,
        address: null,
        chainId: null,
        error: error.code === 4001 
          ? 'Please approve the connection request'
          : error.message || 'Failed to connect wallet',
      };
      this.notify(status);
      return status;
    }
  }

  /**
   * Check existing connection on page load
   */
  async checkConnection(): Promise<WalletStatus> {
    // Don't auto-connect if user manually disconnected
    if (this.getDisconnectFlag()) {
      return {
        isConnected: false,
        address: null,
        chainId: null,
        error: null,
      };
    }

    if (!this.isMetaMaskInstalled()) {
      return {
        isConnected: false,
        address: null,
        chainId: null,
        error: null,
      };
    }

    try {
      const accounts = await this.getConnectedAccounts();
      
      if (accounts.length === 0) {
        return {
          isConnected: false,
          address: null,
          chainId: null,
          error: null,
        };
      }

      const chainId = await this.getCurrentChainId();

      // Check if on correct network
      if (chainId !== SEPOLIA_CHAIN_ID) {
        return {
          isConnected: false,
          address: null,
          chainId: chainId,
          error: 'Please switch to Sepolia Test Network',
        };
      }

      return {
        isConnected: true,
        address: accounts[0],
        chainId: chainId,
        error: null,
      };
    } catch (error) {
      console.error('Error checking wallet connection:', error);
      return {
        isConnected: false,
        address: null,
        chainId: null,
        error: null,
      };
    }
  }

  /**
   * Disconnect wallet (sets flag and notifies)
   */
  disconnect(): void {
    this.setDisconnectFlag(true);
    const status: WalletStatus = {
      isConnected: false,
      address: null,
      chainId: null,
      error: null,
    };
    this.notify(status);
  }

  /**
   * Set up account change listener
   */
  setupAccountsListener(callback: (accounts: string[]) => void): void {
    if (!this.isMetaMaskInstalled()) return;

    // Remove existing listener if any
    if (this.accountsChangeHandler) {
      window.ethereum.removeListener('accountsChanged', this.accountsChangeHandler);
    }

    this.accountsChangeHandler = callback;
    window.ethereum.on('accountsChanged', this.accountsChangeHandler);
  }

  /**
   * Set up chain change listener
   */
  setupChainListener(callback: () => void): void {
    if (!this.isMetaMaskInstalled()) return;

    // Remove existing listener if any
    if (this.chainChangeHandler) {
      window.ethereum.removeListener('chainChanged', this.chainChangeHandler);
    }

    this.chainChangeHandler = callback;
    window.ethereum.on('chainChanged', this.chainChangeHandler);
  }

  /**
   * Remove all event listeners
   */
  removeListeners(): void {
    if (!this.isMetaMaskInstalled()) return;

    if (this.accountsChangeHandler) {
      window.ethereum.removeListener('accountsChanged', this.accountsChangeHandler);
      this.accountsChangeHandler = null;
    }

    if (this.chainChangeHandler) {
      window.ethereum.removeListener('chainChanged', this.chainChangeHandler);
      this.chainChangeHandler = null;
    }
  }

  /**
   * Format address to shortened version
   */
  formatAddress(address: string): string {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  }
}

// Export singleton instance
export const walletService = new WalletService();
