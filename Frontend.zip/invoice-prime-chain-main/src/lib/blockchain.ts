import { createPublicClient, createWalletClient, custom, http, parseUnits, formatUnits, keccak256 } from 'viem';
import { sepolia } from 'viem/chains';
import { supabase } from '@/integrations/supabase/client';
import InvoiceNFTAbi from '@/abi/InvoiceNFT.json';
import PartyRegistryAbi from '@/abi/PartyRegistry.json';
import IInvoiceMarketplaceAbi from '@/abi/IInvoiceMarketplace.json';
import IERC20MinimalAbi from '@/abi/IERC20Minimal.json';
import { CONTRACT_ADDRESSES, CURRENCIES, CONSTANTS } from '@/contracts/constants';
import bs58 from 'bs58';

// Party interface matching the smart contract struct
export interface Party {
  lei: string;
  vleiHash: string;
  isTrusted: boolean;
}

// ========== Input Validation Functions ==========

/**
 * Validate LEI check digits using MOD 97-10 algorithm (ISO 17442)
 */
export function validateLEICheckDigits(lei: string): boolean {
  if (lei.length !== 20) return false;
  
  // Convert letters to numbers (A=10, B=11, ..., Z=35)
  const digits = lei.split('').map(char => {
    const code = char.charCodeAt(0);
    return code >= 65 && code <= 90 
      ? (code - 55).toString() 
      : char;
  }).join('');
  
  // MOD 97 check
  const remainder = BigInt(digits) % 97n;
  return remainder === 1n;
}

/**
 * Convert vLEI credential to bytes32 hash for smart contract
 * Accepts: hex string (0x...), JSON credential, or plain text
 */
export function vleiToBytes32(vlei: string): `0x${string}` {
  const trimmed = vlei.trim();
  
  // If already a 32-byte hex string (66 chars with 0x), use as-is
  if (trimmed.startsWith('0x') && trimmed.length === 66) {
    return trimmed as `0x${string}`;
  }
  
  // Otherwise, compute keccak256 hash
  const encoder = new TextEncoder();
  const data = encoder.encode(trimmed);
  return keccak256(data);
}

// Get Alchemy configuration from Supabase Edge Function
async function getAlchemyConfig() {
  const { data, error } = await supabase.functions.invoke('get-alchemy-config');
  
  if (error) {
    console.error('Failed to get Alchemy config:', error);
    throw new Error('Failed to get blockchain configuration');
  }
  
  return data;
}

// Create public client for reading blockchain data
export async function createViemPublicClient() {
  const config = await getAlchemyConfig();
  
  return createPublicClient({
    chain: sepolia,
    transport: http(config.rpcUrl),
  });
}

// Create wallet client for transactions (uses MetaMask)
export function createViemWalletClient() {
  if (!window.ethereum) {
    throw new Error('MetaMask not installed');
  }

  return createWalletClient({
    chain: sepolia,
    transport: custom(window.ethereum),
  });
}

// Convert IPFS hash to bytes32 for smart contract
function ipfsHashToBytes32(ipfsHash: string): `0x${string}` {
  try {
    // For CIDv0 hashes (starting with "Qm"), decode from base58
    if (ipfsHash.startsWith('Qm')) {
      const decoded = bs58.decode(ipfsHash);
      // Remove the first 2 bytes (multihash identifier and hash length)
      // and take the next 32 bytes (the actual hash)
      const hashBytes = decoded.slice(2, 34);
      
      // Pad to 32 bytes if needed
      const padded = new Uint8Array(32);
      padded.set(hashBytes, 0);
      
      // Convert to hex string
      return `0x${Array.from(padded).map(b => b.toString(16).padStart(2, '0')).join('')}`;
    }
    
    // For other formats, try to extract 32 bytes worth of data
    throw new Error(`Unsupported IPFS hash format: ${ipfsHash}`);
  } catch (error) {
    console.error('Error converting IPFS hash to bytes32:', error);
    throw new Error(`Invalid IPFS hash format: ${ipfsHash}`);
  }
}

// Helper function to convert invoice data for contract
export function formatInvoiceDataForContract(data: {
  amount: string;
  dueDate: string;
  companyName: string;
  industry: string;
}, ipfsHash: string, userAddress: string) {
  const amount = parseUnits(data.amount, 6); // USDC has 6 decimals
  const dueTimestamp = Math.floor(new Date(data.dueDate).getTime() / 1000);
  const docHash = ipfsHashToBytes32(ipfsHash);
  
  return {
    uploader: userAddress as `0x${string}`,
    to: userAddress as `0x${string}`,
    amount,
    ccy: CURRENCIES.USD as `0x${string}`,
    dueDate: dueTimestamp, // uint64
    debtor: '0x0000000000000000000000000000000000000000' as `0x${string}`, // Placeholder
    docHash,
    flags: CONSTANTS.ZERO_FLAGS,
    kreditor: userAddress as `0x${string}`,
    discountBps: 1000, // 10% discount (uint16)
    riskBps: 800,      // 8% risk (uint16)
    listed: true,
    industry: data.industry
  };
}

// Check if an address is trusted in the PartyRegistry
export async function checkIfAddressTrusted(userAddress: string): Promise<boolean> {
  try {
    const publicClient = await createViemPublicClient();
    
    const result = await (publicClient as any).readContract({
      address: CONTRACT_ADDRESSES.REG as `0x${string}`,
      abi: PartyRegistryAbi,
      functionName: 'isTrusted',
      args: [userAddress as `0x${string}`],
    });
    
    return result as boolean;
  } catch (error) {
    console.error('Error checking address trust:', error);
    return false;
  }
}

// Get party information from the PartyRegistry
export async function getPartyInfo(userAddress: string): Promise<Party | null> {
  try {
    const publicClient = await createViemPublicClient();
    
    const result = await (publicClient as any).readContract({
      address: CONTRACT_ADDRESSES.REG as `0x${string}`,
      abi: PartyRegistryAbi,
      functionName: 'partyOf',
      args: [userAddress as `0x${string}`],
    });
    
    console.log('getPartyInfo result:', result, typeof result);
    
    // Handle different possible result formats from viem
    let lei: string, vleiHash: string, isTrusted: boolean;
    
    if (Array.isArray(result)) {
      // If result is an array, destructure it
      [lei, vleiHash, isTrusted] = result as [string, string, boolean];
    } else if (result && typeof result === 'object') {
      // If result is an object with properties, access them directly
      lei = result.lei || result[0] || '';
      vleiHash = result.vleiHash || result[1] || '';
      isTrusted = result.isTrusted !== undefined ? result.isTrusted : (result[2] || false);
    } else {
      // If result is null/undefined or unexpected format
      return null;
    }
    
    // Return null if party is not registered (empty LEI)
    if (!lei || lei.length === 0) {
      return null;
    }
    
    return {
      lei,
      vleiHash,
      isTrusted
    };
  } catch (error) {
    console.error('Error getting party info:', error);
    return null;
  }
}

/**
 * Register a party with LEI and vLEI, and trigger automatic verification
 * Uses registerAndVerifyAuto() to auto-generate presentationId and start verification
 */
export async function registerParty(lei: string, vleiInput: string) {
  try {
    // Validate LEI format and check digits
    if (!validateLEICheckDigits(lei)) {
      throw new Error('Invalid LEI: Check digits validation failed. Please verify your LEI code.');
    }
    
    // Convert vLEI to bytes32 hash
    const vleiHash = vleiToBytes32(vleiInput);
    
    const walletClient = createViemWalletClient();
    const publicClient = await createViemPublicClient();
    
    // Get user address
    const [userAddress] = await walletClient.getAddresses();
    
    // Simulate the transaction first
    await publicClient.simulateContract({
      address: CONTRACT_ADDRESSES.REG as `0x${string}`,
      abi: PartyRegistryAbi,
      functionName: 'registerAndVerifyAuto',
      args: [lei, vleiHash],
      account: userAddress,
    });
    
    // Write the transaction using registerAndVerifyAuto
    const hash = await walletClient.writeContract({
      address: CONTRACT_ADDRESSES.REG as `0x${string}`,
      abi: PartyRegistryAbi,
      functionName: 'registerAndVerifyAuto',
      args: [lei, vleiHash],
      account: userAddress,
      chain: sepolia,
    });
    
    // Wait for transaction receipt
    const receipt = await publicClient.waitForTransactionReceipt({ hash });
    
    return {
      transactionHash: hash,
      receipt
    };
  } catch (error) {
    console.error('Error registering party:', error);
    throw error;
  }
}

// Mint invoice NFT using viem with trust check
export async function mintInvoiceNFTWithViem(invoiceData: {
  amount: string;
  dueDate: string;
  companyName: string;
  industry: string;
}, ipfsHash: string) {
  try {
    const walletClient = createViemWalletClient();
    const publicClient = await createViemPublicClient();
    
    // Get user address
    const [userAddress] = await walletClient.getAddresses();
    
    // Check if user is trusted before attempting to mint
    const isTrusted = await checkIfAddressTrusted(userAddress);
    if (!isTrusted) {
      throw new Error('UNTRUSTED_ADDRESS: Your address is not registered or trusted in the PartyRegistry. Please register and get verified before minting invoices.');
    }
    
    // Format data for contract
    const contractData = formatInvoiceDataForContract(invoiceData, ipfsHash, userAddress);
    
    // Simulate the transaction first
    const { result } = await publicClient.simulateContract({
      address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
      abi: InvoiceNFTAbi,
      functionName: 'mintInvoice',
      args: [
        contractData.uploader,
        contractData.to,
        contractData.amount,
        contractData.ccy,
        contractData.dueDate,
        contractData.debtor,
        contractData.docHash,
        contractData.flags,
        contractData.kreditor,
        contractData.discountBps,
        contractData.riskBps,
        contractData.listed,
        contractData.industry
      ],
      account: userAddress,
    });
    
    // Write the transaction
    const hash = await walletClient.writeContract({
      address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
      abi: InvoiceNFTAbi,
      functionName: 'mintInvoice',
      args: [
        contractData.uploader,
        contractData.to,
        contractData.amount,
        contractData.ccy,
        contractData.dueDate,
        contractData.debtor,
        contractData.docHash,
        contractData.flags,
        contractData.kreditor,
        contractData.discountBps,
        contractData.riskBps,
        contractData.listed,
        contractData.industry
      ],
      account: userAddress,
      chain: sepolia,
    });
    
    // Wait for transaction receipt
    const receipt = await publicClient.waitForTransactionReceipt({ hash });
    
    // Extract token ID from logs
    const tokenId = result as bigint;
    
    return {
      tokenId: tokenId.toString(),
      transactionHash: hash,
      receipt
    };
  } catch (error) {
    console.error('Error minting NFT with viem:', error);
    throw error;
  }
}

// Market Invoice interface for the marketplace
export interface MarketInvoice {
  tokenId: string;
  invoiceNumber: string;
  company: string;
  industry: string;
  originalAmount: number;
  discountRate: number;
  investmentAmount: number;
  expectedReturn: number;
  dueDate: string;
  daysUntilDue: number;
  creditRating: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B';
  riskLevel: 'low' | 'medium' | 'high';
  description: string;
  owner: string;
  debtor: string;
  settled: boolean;
  currency: string;
  approvalStatus: boolean;
}

// Helper to convert bytes3 currency to string
function bytes3ToStr(bytes3: string): string {
  try {
    const hex = bytes3.replace('0x', '');
    let str = '';
    for (let i = 0; i < hex.length; i += 2) {
      const charCode = parseInt(hex.substr(i, 2), 16);
      if (charCode !== 0) str += String.fromCharCode(charCode);
    }
    return str || 'USD';
  } catch {
    return 'USD';
  }
}

// Helper to determine credit rating based on risk
function getRiskBasedRating(riskBps: number): 'AAA' | 'AA' | 'A' | 'BBB' | 'BB' | 'B' {
  if (riskBps < 200) return 'AAA';
  if (riskBps < 400) return 'AA';
  if (riskBps < 600) return 'A';
  if (riskBps < 800) return 'BBB';
  if (riskBps < 1000) return 'BB';
  return 'B';
}

// Helper to determine risk level
function getRiskLevel(riskBps: number): 'low' | 'medium' | 'high' {
  if (riskBps < 500) return 'low';
  if (riskBps < 1000) return 'medium';
  return 'high';
}

// Helper: Find the highest minted token ID using binary search
async function findMaxTokenId(publicClient: any): Promise<number> {
  // First, check if token 1 exists
  try {
    await (publicClient as any).readContract({
      address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
      abi: InvoiceNFTAbi,
      functionName: 'ownerOf',
      args: [BigInt(1)],
    });
  } catch {
    // No tokens minted yet
    return 0;
  }

  // Binary search to find the upper bound
  let low = 1;
  let high = 1000; // Start with reasonable upper bound
  
  // Find approximate upper bound by doubling
  while (true) {
    try {
      await (publicClient as any).readContract({
        address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
        abi: InvoiceNFTAbi,
        functionName: 'ownerOf',
        args: [BigInt(high)],
      });
      low = high;
      high *= 2;
    } catch {
      break;
    }
  }

  // Binary search between low and high
  while (low < high) {
    const mid = Math.floor((low + high + 1) / 2);
    try {
      await (publicClient as any).readContract({
        address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
        abi: InvoiceNFTAbi,
        functionName: 'ownerOf',
        args: [BigInt(mid)],
      });
      low = mid;
    } catch {
      high = mid - 1;
    }
  }

  return low;
}

// Company Invoice interface for company dashboard
export interface CompanyInvoice {
  tokenId: string;
  invoiceNumber: string;
  originalAmount: number;
  discountRate: number;
  payoutAmount: number;
  status: 'pending' | 'funded' | 'settled';
  createdDate: string;
  dueDate: string;
  currentOwner: string;
  investor: string;
  industry: string;
  currency: string;
  listed: boolean;
  settled: boolean;
  approvalStatus: boolean;
}

// Investor Invoice interface for investor dashboard
export interface InvestorInvoice {
  tokenId: string;
  invoiceNumber: string;
  company: string;
  industry: string;
  investmentAmount: number;
  expectedReturn: number;
  status: 'active' | 'settled';
  purchaseDate: string;
  dueDate: string;
  daysUntilDue: number;
  currency: string;
  settled: boolean;
  kreditor: string;
  discountRate: number;
}

/**
 * Approve the marketplace to transfer a specific invoice NFT
 * @param tokenId - The invoice NFT token ID
 * @returns Transaction hash
 */
export async function approveMarketplaceForInvoice(tokenId: string): Promise<string> {
  try {
    const walletClient = createViemWalletClient();
    const publicClient = await createViemPublicClient();
    
    // Get user address
    const [userAddress] = await walletClient.getAddresses();
    
    // Simulate the transaction first
    await publicClient.simulateContract({
      address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
      abi: InvoiceNFTAbi,
      functionName: 'approve',
      args: [CONTRACT_ADDRESSES.MKT as `0x${string}`, BigInt(tokenId)],
      account: userAddress,
    });
    
    // Write the transaction
    const hash = await walletClient.writeContract({
      address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
      abi: InvoiceNFTAbi,
      functionName: 'approve',
      args: [CONTRACT_ADDRESSES.MKT as `0x${string}`, BigInt(tokenId)],
      account: userAddress,
      chain: sepolia,
    });
    
    // Wait for transaction receipt
    await publicClient.waitForTransactionReceipt({ hash });
    
    return hash;
  } catch (error) {
    console.error('Error approving marketplace for invoice:', error);
    throw error;
  }
}

/**
 * Check if marketplace is approved for a specific invoice NFT
 * @param tokenId - The invoice NFT token ID
 * @returns Whether the marketplace is approved
 */
export async function isMarketplaceApprovedForInvoice(tokenId: string): Promise<boolean> {
  try {
    const publicClient = await createViemPublicClient();
    
    // Get the approved address for this token
    const approvedAddress = await (publicClient as any).readContract({
      address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
      abi: InvoiceNFTAbi,
      functionName: 'getApproved',
      args: [BigInt(tokenId)],
    }) as string;
    
    return approvedAddress.toLowerCase() === CONTRACT_ADDRESSES.MKT.toLowerCase();
  } catch (error) {
    console.error('Error checking marketplace approval:', error);
    return false;
  }
}

// Get company's uploaded invoices (kreditor === userAddress)
export async function getCompanyInvoices(userAddress: string): Promise<CompanyInvoice[]> {
  try {
    const publicClient = await createViemPublicClient();
    const maxTokenId = await findMaxTokenId(publicClient);
    
    if (maxTokenId === 0) return [];

    const companyInvoices: CompanyInvoice[] = [];
    const batchSize = 10;

    for (let tokenId = 1; tokenId <= maxTokenId; tokenId += batchSize) {
      const batchPromises = [];
      
      for (let i = 0; i < batchSize && tokenId + i <= maxTokenId; i++) {
        const currentTokenId = tokenId + i;
        batchPromises.push(
          (async () => {
            try {
              const [metaData, invoiceData, pricingData, industry, owner] = await Promise.all([
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'invoiceMeta',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'invoices',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'getPricing',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'industryOf',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'ownerOf',
                  args: [BigInt(currentTokenId)],
                }),
              ]);

              const kreditor = (metaData[0] as string).toLowerCase();
              
              // Only include if this user is the kreditor (original creator)
              if (kreditor !== userAddress.toLowerCase()) return null;

              const amount = invoiceData[0] as bigint;
              const ccy = invoiceData[1] as string;
              const dueDate = invoiceData[2] as bigint;
              const settled = invoiceData[6] as boolean;
              const discountBps = metaData[2] as number;
              const listed = metaData[4] as boolean;
              const netPrice = pricingData[3] as bigint;

              const originalAmount = Number(amount) / CONSTANTS.MICRO_1;
              const payoutAmount = Number(netPrice) / CONSTANTS.MICRO_1;
              const ownerAddr = (owner as string).toLowerCase();

              // Determine status
              let status: 'pending' | 'funded' | 'settled';
              if (settled) {
                status = 'settled';
              } else if (ownerAddr !== kreditor) {
                status = 'funded'; // Sold to investor
              } else {
                status = 'pending'; // Not sold yet
              }

              const dueDateMs = Number(dueDate) * 1000;
              const dueDateStr = new Date(dueDateMs).toISOString().split('T')[0];
              const currency = bytes3ToStr(ccy);

              return {
                tokenId: currentTokenId.toString(),
                invoiceNumber: `INV-${currentTokenId.toString().padStart(6, '0')}`,
                originalAmount,
                discountRate: discountBps / 100,
                payoutAmount,
                status,
                createdDate: dueDateStr, // Using dueDate as proxy for now
                dueDate: dueDateStr,
                currentOwner: owner as string,
                investor: ownerAddr !== kreditor ? `${owner.slice(0, 6)}...${owner.slice(-4)}` : 'PENDING MATCH',
                industry: industry as string || 'General',
                currency,
                listed,
                settled,
              } as CompanyInvoice;
            } catch (error) {
              console.error(`Error fetching company invoice ${currentTokenId}:`, error);
              return null;
            }
          })()
        );
      }

      const batchResults = await Promise.all(batchPromises);
      batchResults.forEach(result => {
        if (result) companyInvoices.push(result);
      });
    }

    return companyInvoices;
  } catch (error) {
    console.error('Error fetching company invoices:', error);
    throw error;
  }
}

// Get investor's purchased invoices (owner === userAddress && kreditor !== userAddress)
export async function getInvestorInvoices(userAddress: string): Promise<InvestorInvoice[]> {
  try {
    const publicClient = await createViemPublicClient();
    const maxTokenId = await findMaxTokenId(publicClient);
    
    if (maxTokenId === 0) return [];

    const investorInvoices: InvestorInvoice[] = [];
    const batchSize = 10;

    for (let tokenId = 1; tokenId <= maxTokenId; tokenId += batchSize) {
      const batchPromises = [];
      
      for (let i = 0; i < batchSize && tokenId + i <= maxTokenId; i++) {
        const currentTokenId = tokenId + i;
        batchPromises.push(
          (async () => {
            try {
              const [owner, metaData, invoiceData, pricingData, industry] = await Promise.all([
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'ownerOf',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'invoiceMeta',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'invoices',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'getPricing',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'industryOf',
                  args: [BigInt(currentTokenId)],
                }),
              ]);

              const ownerAddr = (owner as string).toLowerCase();
              const kreditor = (metaData[0] as string).toLowerCase();
              
              // Only include if user owns it AND didn't create it
              if (ownerAddr !== userAddress.toLowerCase() || kreditor === userAddress.toLowerCase()) {
                return null;
              }

              const amount = invoiceData[0] as bigint;
              const ccy = invoiceData[1] as string;
              const dueDate = invoiceData[2] as bigint;
              const settled = invoiceData[6] as boolean;
              const discountBps = metaData[2] as number;
              const netPrice = pricingData[3] as bigint;

              const originalAmount = Number(amount) / CONSTANTS.MICRO_1;
              const investmentAmount = Number(netPrice) / CONSTANTS.MICRO_1;
              
              const dueDateMs = Number(dueDate) * 1000;
              const now = Date.now();
              const daysUntilDue = Math.max(0, Math.ceil((dueDateMs - now) / (1000 * 60 * 60 * 24)));
              const dueDateStr = new Date(dueDateMs).toISOString().split('T')[0];
              const currency = bytes3ToStr(ccy);

              return {
                tokenId: currentTokenId.toString(),
                invoiceNumber: `INV-${currentTokenId.toString().padStart(6, '0')}`,
                company: `${kreditor.slice(0, 6)}...${kreditor.slice(-4)}`,
                industry: industry as string || 'General',
                investmentAmount,
                expectedReturn: originalAmount,
                status: settled ? 'settled' : 'active',
                purchaseDate: dueDateStr, // Using dueDate as proxy
                dueDate: dueDateStr,
                daysUntilDue,
                currency,
                settled,
                kreditor,
                discountRate: discountBps / 100,
              } as InvestorInvoice;
            } catch (error) {
              console.error(`Error fetching investor invoice ${currentTokenId}:`, error);
              return null;
            }
          })()
        );
      }

      const batchResults = await Promise.all(batchPromises);
      batchResults.forEach(result => {
        if (result) investorInvoices.push(result);
      });
    }

    return investorInvoices;
  } catch (error) {
    console.error('Error fetching investor invoices:', error);
    throw error;
  }
}

// Get market invoices (listed, not settled, not owned by user)
export async function getMarketInvoices(userAddress: string): Promise<MarketInvoice[]> {
  try {
    const publicClient = await createViemPublicClient();
    
    // Step 1: Find the highest minted token ID
    const maxTokenId = await findMaxTokenId(publicClient);
    
    if (maxTokenId === 0) {
      console.log('No invoices minted yet');
      return [];
    }

    console.log(`Scanning ${maxTokenId} invoices for listed ones...`);

    // Step 2: Check each token to see if it's listed
    const marketInvoices: MarketInvoice[] = [];
    const batchSize = 10; // Process in batches for better UX

    for (let tokenId = 1; tokenId <= maxTokenId; tokenId += batchSize) {
      const batchPromises = [];
      
      for (let i = 0; i < batchSize && tokenId + i <= maxTokenId; i++) {
        const currentTokenId = tokenId + i;
        batchPromises.push(
          (async () => {
            try {
              // Fetch full data for listed invoice
              const [metaData, invoiceData, pricingData, industry, owner] = await Promise.all([
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'invoiceMeta',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'invoices',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'getPricing',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'industryOf',
                  args: [BigInt(currentTokenId)],
                }),
                (publicClient as any).readContract({
                  address: CONTRACT_ADDRESSES.NFT as `0x${string}`,
                  abi: InvoiceNFTAbi,
                  functionName: 'ownerOf',
                  args: [BigInt(currentTokenId)],
                }),
              ]);

              const isListed = metaData[4] as boolean;
              const settled = invoiceData[6] as boolean;

              // Filter: must be listed, not settled, and not owned by current user
              if (!isListed || settled) return null;
              if ((owner as string).toLowerCase() === userAddress.toLowerCase()) return null;

              // Parse the data
              const amount = invoiceData[0] as bigint;
              const ccy = invoiceData[1] as string;
              const dueDate = invoiceData[2] as bigint;
              const debtor = invoiceData[3] as string;

              const discountBps = metaData[2] as number;
              const riskBps = metaData[3] as number;

              const netPrice = pricingData[3] as bigint;

              // Convert amounts from microunits (1e6) to regular numbers
              const originalAmount = Number(amount) / CONSTANTS.MICRO_1;
              const investmentAmount = Number(netPrice) / CONSTANTS.MICRO_1;
              
              // Calculate days until due
              const dueDateMs = Number(dueDate) * 1000;
              const now = Date.now();
              const daysUntilDue = Math.max(0, Math.ceil((dueDateMs - now) / (1000 * 60 * 60 * 24)));

              // Format due date
              const dueDateStr = new Date(dueDateMs).toISOString().split('T')[0];

              // Convert currency
              const currency = bytes3ToStr(ccy);

              // Create market invoice object
              return {
                tokenId: currentTokenId.toString(),
                invoiceNumber: `INV-${currentTokenId.toString().padStart(6, '0')}`,
                company: `TOKEN #${currentTokenId}`,
                industry: industry as string || 'General',
                originalAmount,
                discountRate: discountBps / 100,
                investmentAmount,
                expectedReturn: originalAmount,
                dueDate: dueDateStr,
                daysUntilDue,
                creditRating: getRiskBasedRating(riskBps),
                riskLevel: getRiskLevel(riskBps),
                description: `Invoice NFT ${currentTokenId} - ${currency} ${originalAmount.toLocaleString()}`,
                owner: owner as string,
                debtor: debtor as string,
                settled: false, // Already filtered out settled invoices
                currency,
              } as MarketInvoice;
            } catch (error) {
              console.error(`Error fetching data for token ${currentTokenId}:`, error);
              return null;
            }
          })()
        );
      }

      const batchResults = await Promise.all(batchPromises);
      batchResults.forEach(result => {
        if (result) marketInvoices.push(result);
      });
    }

    console.log(`Found ${marketInvoices.length} listed invoices out of ${maxTokenId} total`);
    return marketInvoices;
  } catch (error) {
    console.error('Error fetching market invoices:', error);
    throw error;
  }
}

// ========== USDC Investment Functions ==========

/**
 * Get the USDC amount required to purchase an invoice
 * Calls InvoiceMarketplace.quoteBuyAmount to get exact amount needed
 * @param tokenId - The invoice NFT token ID
 * @returns USDC amount in 6-decimal format (e.g., 1000000 = 1.00 USDC)
 */
export async function getUSDCPriceForInvoice(tokenId: string): Promise<bigint> {
  try {
    const publicClient = await createViemPublicClient();
    
    const usdcAmount = await (publicClient as any).readContract({
      address: CONTRACT_ADDRESSES.MKT as `0x${string}`,
      abi: IInvoiceMarketplaceAbi,
      functionName: 'quoteBuyAmount',
      args: [CONTRACT_ADDRESSES.USDC as `0x${string}`, BigInt(tokenId)],
    });
    
    return usdcAmount as bigint;
  } catch (error) {
    console.error('Error getting USDC price for invoice:', error);
    throw error;
  }
}

/**
 * Approve USDC spending for the marketplace contract
 * @param spenderAddress - The marketplace contract address
 * @param amount - Amount of USDC to approve (in 6-decimal format)
 * @returns Transaction hash
 */
export async function approveUSDC(spenderAddress: string, amount: bigint): Promise<string> {
  try {
    const walletClient = createViemWalletClient();
    const publicClient = await createViemPublicClient();
    
    // Get user address
    const [userAddress] = await walletClient.getAddresses();
    
    // Simulate the transaction first
    await publicClient.simulateContract({
      address: CONTRACT_ADDRESSES.USDC as `0x${string}`,
      abi: IERC20MinimalAbi,
      functionName: 'approve',
      args: [spenderAddress as `0x${string}`, amount],
      account: userAddress,
    });
    
    // Write the transaction
    const hash = await walletClient.writeContract({
      address: CONTRACT_ADDRESSES.USDC as `0x${string}`,
      abi: IERC20MinimalAbi,
      functionName: 'approve',
      args: [spenderAddress as `0x${string}`, amount],
      account: userAddress,
      chain: sepolia,
    });
    
    // Wait for transaction receipt
    await publicClient.waitForTransactionReceipt({ hash });
    
    return hash;
  } catch (error) {
    console.error('Error approving USDC:', error);
    throw error;
  }
}

/**
 * Purchase an invoice with USDC
 * @param tokenId - The invoice NFT token ID
 * @param maxPayAmount - Maximum USDC amount willing to pay (slippage protection)
 * @returns Transaction hash
 */
export async function buyInvoiceWithUSDC(tokenId: string, maxPayAmount: bigint): Promise<string> {
  try {
    const walletClient = createViemWalletClient();
    const publicClient = await createViemPublicClient();
    
    // Get user address
    const [userAddress] = await walletClient.getAddresses();
    
    // Check if buyer is trusted before attempting purchase
    const isTrusted = await checkIfAddressTrusted(userAddress);
    if (!isTrusted) {
      throw new Error('BUYER_NOT_TRUSTED: You must be registered and verified in the PartyRegistry before purchasing invoices. Please register with a valid LEI.');
    }
    
    // Simulate the transaction first
    await publicClient.simulateContract({
      address: CONTRACT_ADDRESSES.MKT as `0x${string}`,
      abi: IInvoiceMarketplaceAbi,
      functionName: 'buyWithStable',
      args: [
        CONTRACT_ADDRESSES.USDC as `0x${string}`,
        BigInt(tokenId),
        maxPayAmount
      ],
      account: userAddress,
    });
    
    // Write the transaction
    const hash = await walletClient.writeContract({
      address: CONTRACT_ADDRESSES.MKT as `0x${string}`,
      abi: IInvoiceMarketplaceAbi,
      functionName: 'buyWithStable',
      args: [
        CONTRACT_ADDRESSES.USDC as `0x${string}`,
        BigInt(tokenId),
        maxPayAmount
      ],
      account: userAddress,
      chain: sepolia,
    });
    
    // Wait for transaction receipt
    await publicClient.waitForTransactionReceipt({ hash });
    
    return hash;
  } catch (error) {
    console.error('Error buying invoice with USDC:', error);
    throw error;
  }
}