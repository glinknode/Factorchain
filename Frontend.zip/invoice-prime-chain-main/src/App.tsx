import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { WalletProvider } from "@/contexts/WalletContext";
import { PartyRegistryProvider } from "@/contexts/PartyRegistryContext";
import { InvoiceCacheProvider } from "@/contexts/InvoiceCacheContext";
import Header from "@/components/Header";
import Index from "./pages/Index";
import Company from "./pages/Company";
import Investor from "./pages/Investor";
import Market from "./pages/Market";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <WalletProvider>
      <PartyRegistryProvider>
        <InvoiceCacheProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Header />
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/company" element={<Company />} />
                <Route path="/investor" element={<Investor />} />
                <Route path="/market" element={<Market />} />
                {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </InvoiceCacheProvider>
      </PartyRegistryProvider>
    </WalletProvider>
  </QueryClientProvider>
);

export default App;
