import InvestorDashboard from "@/components/InvestorDashboard";

const Investor = () => {
  return (
    <div className="min-h-screen bg-background">
      <InvestorDashboard />
    </div>
  );
};

export default Investor;