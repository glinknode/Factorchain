import CompanyDashboard from "@/components/CompanyDashboard";

const Company = () => {
  return (
    <div className="min-h-screen bg-background">
      <CompanyDashboard />
    </div>
  );
};

export default Company;