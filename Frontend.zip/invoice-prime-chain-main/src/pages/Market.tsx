import PartyRegistryStatus from "@/components/PartyRegistryStatus";
import WalletConnectDialog from "@/components/WalletConnectDialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Building2, DollarSign, TrendingUp, Clock, Search, RefreshCw, Loader2, CheckCircle2, Shield, UserPlus, AlertCircle, X, Coins, Network, Calendar, ListFilter } from "lucide-react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useWallet } from "@/hooks/useWallet";
import { usePartyRegistry } from "@/contexts/PartyRegistryContext";
import { useInvoiceCache } from "@/contexts/InvoiceCacheContext";
import { MarketInvoice as BlockchainMarketInvoice, getUSDCPriceForInvoice, approveUSDC, buyInvoiceWithUSDC, registerParty, isMarketplaceApprovedForInvoice } from "@/lib/blockchain";
import { toast } from "sonner";
import { CONTRACT_ADDRESSES } from "@/contracts/constants";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

// Use the blockchain interface
type MarketInvoice = BlockchainMarketInvoice & { id: string };

const leiSchema = z.object({
  lei: z.string()
    .min(20, "LEI must be exactly 20 characters")
    .max(20, "LEI must be exactly 20 characters")
    .regex(/^[A-Z0-9]{20}$/, "LEI must contain only uppercase letters and numbers"),
  vlei: z.string().min(1, "vLEI is required"),
});

type LEIFormData = z.infer<typeof leiSchema>;

const Market = () => {
  const navigate = useNavigate();
  const { isConnected } = useWallet();
  const { status: partyStatus, invalidateAndRefresh: invalidatePartyRegistry } = usePartyRegistry();
  const { marketInvoices: cachedInvoices, isLoading: cacheLoading, invalidateAndRefresh: refreshCache } = useInvoiceCache();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedIndustry, setSelectedIndustry] = useState("all");
  const [selectedRisk, setSelectedRisk] = useState("all");
  const [sortBy, setSortBy] = useState("return");
  const [isInvestModalOpen, setIsInvestModalOpen] = useState(false);
  const [showWalletDialog, setShowWalletDialog] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<MarketInvoice | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  
  // Investment flow states
  const [investmentStep, setInvestmentStep] = useState<'method' | 'calculating' | 'approving' | 'purchasing' | 'success'>('method');
  const [calculatedUSDC, setCalculatedUSDC] = useState<string>('0');
  const [transactionHash, setTransactionHash] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [isRegisterDialogOpen, setIsRegisterDialogOpen] = useState<boolean>(false);
  
  // Add id field to cached invoices
  const invoices: MarketInvoice[] = cachedInvoices.map(inv => ({
    ...inv,
    id: inv.tokenId,
  }));

  const form = useForm<LEIFormData>({
    resolver: zodResolver(leiSchema),
    defaultValues: {
      lei: "",
      vlei: "",
    },
  });

  const handleRefresh = async () => {
    try {
      setRefreshing(true);
      await refreshCache();
      toast.success('All NFTs have been refreshed');
    } catch (error) {
      console.error('Error refreshing market:', error);
      toast.error('Failed to refresh market data');
    } finally {
      setRefreshing(false);
    }
  };

  const getRatingColor = (rating: MarketInvoice['creditRating']) => {
    switch (rating) {
      case 'AAA': case 'AA': return 'bg-neon-green text-foreground';
      case 'A': return 'bg-electric-blue text-background';
      case 'BBB': return 'bg-electric-yellow text-foreground';
      case 'BB': case 'B': return 'bg-hot-pink text-background';
    }
  };

  const getRiskColor = (risk: MarketInvoice['riskLevel']) => {
    switch (risk) {
      case 'low': return 'bg-neon-green text-foreground';
      case 'medium': return 'bg-electric-yellow text-foreground';
      case 'high': return 'bg-hot-pink text-background';
    }
  };

  const filteredInvoices = invoices
    .filter(invoice => {
      const matchesSearch = invoice.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           invoice.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           invoice.tokenId.includes(searchQuery);
      const matchesIndustry = selectedIndustry === "all" || invoice.industry === selectedIndustry;
      const matchesRisk = selectedRisk === "all" || invoice.riskLevel === selectedRisk;
      return matchesSearch && matchesIndustry && matchesRisk;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'return': return (b.expectedReturn - b.investmentAmount) - (a.expectedReturn - a.investmentAmount);
        case 'amount': return b.originalAmount - a.originalAmount;
        case 'due': return a.daysUntilDue - b.daysUntilDue;
        case 'rate': return b.discountRate - a.discountRate;
        default: return 0;
      }
    });

  const handleRegister = async (data: LEIFormData) => {
    try {
      setIsRegistering(true);
      await registerParty(data.lei, data.vlei);
      toast.success("Registration Successful! Please wait for verification.");
      setIsRegisterDialogOpen(false);
      form.reset();
      // Refresh status after registration
      await invalidatePartyRegistry();
    } catch (error) {
      console.error("Registration failed:", error);
      toast.error("Registration Failed. Please try again.");
    } finally {
      setIsRegistering(false);
    }
  };

  const handleInvest = async (invoice: MarketInvoice) => {
    if (!isConnected) {
      setShowWalletDialog(true);
      return;
    }
    
    setSelectedInvoice(invoice);
    setInvestmentStep('method');
    setCalculatedUSDC('0');
    setTransactionHash('');
    setIsProcessing(false);
    setIsInvestModalOpen(true);
  };

  const handlePaymentOption = async (option: 'stablecoin' | 'swift') => {
    if (!selectedInvoice) return;

    if (option === 'swift') {
      alert(`SWIFT payment not yet implemented for ${selectedInvoice.invoiceNumber}`);
      return;
    }

    // Handle stablecoin payment flow
    try {
      setIsProcessing(true);
      setInvestmentStep('calculating');

      // Step 1: Calculate USDC amount
      const quotedAmount = await getUSDCPriceForInvoice(selectedInvoice.tokenId);
      
      // Add 1% buffer for slippage protection
      const bufferedAmount = (quotedAmount * 101n) / 100n;
      
      // Convert to display format (6 decimals)
      const displayAmount = (Number(bufferedAmount) / 1e6).toFixed(2);
      setCalculatedUSDC(displayAmount);
      
      setInvestmentStep('approving');
      setIsProcessing(false);
      
      toast.info(`Required: ${displayAmount} USDC (includes 1% buffer)`);
    } catch (error: any) {
      console.error('Error calculating USDC amount:', error);
      toast.error('Failed to calculate USDC amount: ' + (error.message || 'Unknown error'));
      setIsProcessing(false);
      setInvestmentStep('method');
    }
  };

  const handleApprove = async () => {
    if (!selectedInvoice) return;

    try {
      setIsProcessing(true);
      
      // Convert display amount back to bigint (6 decimals)
      const bufferedAmount = BigInt(Math.floor(parseFloat(calculatedUSDC) * 1e6));
      
      toast.info('Approving USDC... Please confirm in your wallet');
      
      const approveHash = await approveUSDC(CONTRACT_ADDRESSES.MKT, bufferedAmount);
      
      toast.success('USDC approved successfully!');
      setInvestmentStep('purchasing');
      setIsProcessing(false);
    } catch (error: any) {
      console.error('Error approving USDC:', error);
      toast.error('Failed to approve USDC: ' + (error.message || 'User rejected transaction'));
      setIsProcessing(false);
    }
  };

  const handleCompletePurchase = async () => {
    if (!selectedInvoice) return;

    try {
      setIsProcessing(true);
      
      // Convert display amount back to bigint (6 decimals)
      const bufferedAmount = BigInt(Math.floor(parseFloat(calculatedUSDC) * 1e6));
      
      toast.info('Purchasing invoice... Please confirm in your wallet');
      
      const purchaseHash = await buyInvoiceWithUSDC(selectedInvoice.tokenId, bufferedAmount);
      
      setTransactionHash(purchaseHash);
      setInvestmentStep('success');
      setIsProcessing(false);
      
      toast.success('Purchase successful! Invoice NFT transferred to your wallet');
      
      // Refresh invoice list after 2 seconds
      setTimeout(async () => {
        await refreshCache();
        closeModal();
      }, 2000);
    } catch (error: any) {
      console.error('Error purchasing invoice:', error);
      
      // Check if error is about buyer trust
      if (error.message?.includes('BUYER_NOT_TRUSTED') || error.message?.includes('buyer not trusted')) {
        toast.error('You must register and be verified before purchasing. Please close this dialog and register above.', {
          duration: 6000,
        });
      } else {
        toast.error('Failed to purchase invoice: ' + (error.message || 'Transaction failed'));
      }
      
      setIsProcessing(false);
    }
  };

  const closeModal = () => {
    setIsInvestModalOpen(false);
    setSelectedInvoice(null);
    setInvestmentStep('method');
    setCalculatedUSDC('0');
    setTransactionHash('');
    setIsProcessing(false);
    setIsRegisterDialogOpen(false);
  };

  return (
    <div className="min-h-screen bg-background">
      
      <div className="container mx-auto px-4 md:px-6 py-6 md:py-8">
        {/* Header */}
        <div className="mb-6 md:mb-8">
          <div className="flex items-center justify-between">
          <div>
            <div className="brutal-card p-2 inline-block mb-3 md:mb-4 bg-card">
              <span className="text-xs md:text-sm font-black uppercase tracking-wider text-steel">
                INVOICE MARKETPLACE
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-black mb-2">
              INVESTMENT <span className="electric-text">OPPORTUNITIES</span>
            </h1>
            <p className="text-sm md:text-base lg:text-lg text-steel font-medium">
              Discover and invest in premium invoices from verified companies
            </p>
          </div>
        </div>
      </div>

        {/* Market Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
          <div className="brutal-card p-6 bg-electric-blue">
            <div className="text-3xl font-black text-background">
              ${filteredInvoices.reduce((sum, inv) => sum + inv.originalAmount, 0).toLocaleString()}
            </div>
            <div className="text-sm font-bold text-background uppercase">
              TOTAL AVAILABLE
            </div>
          </div>
          
          <div className="brutal-card p-6 bg-neon-green">
            <div className="text-3xl font-black text-foreground">
              {filteredInvoices.length}
            </div>
            <div className="text-sm font-bold text-foreground uppercase">
              OPPORTUNITIES
            </div>
          </div>
          
          <div className="brutal-card p-6 bg-electric-yellow">
            <div className="text-3xl font-black text-foreground">
              {filteredInvoices.length > 0 
                ? (filteredInvoices.reduce((sum, inv) => sum + inv.discountRate, 0) / filteredInvoices.length).toFixed(1)
                : '0.0'}%
            </div>
            <div className="text-sm font-bold text-foreground uppercase">
              AVG DISCOUNT
            </div>
          </div>
          
          <div className="brutal-card p-6 bg-hot-pink">
            <div className="text-3xl font-black text-background">
              {filteredInvoices.length > 0 
                ? Math.round(filteredInvoices.reduce((sum, inv) => sum + inv.daysUntilDue, 0) / filteredInvoices.length)
                : 0}
            </div>
            <div className="text-sm font-bold text-background uppercase">
              AVG DAYS TO MATURITY
            </div>
          </div>
        </div>

      {/* PartyRegistry Status */}
      <PartyRegistryStatus purpose="invest" />

        {/* Filters */}
        <div className="brutal-card p-4 md:p-6 mb-6 md:mb-8 bg-card">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
            <div>
              <label className="block text-sm font-black uppercase text-steel mb-2">
                SEARCH
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-steel" />
                <Input
                  placeholder="Company or invoice..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 brutal-border font-bold"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-black uppercase text-steel mb-2">
                INDUSTRY
              </label>
              <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
                <SelectTrigger className="brutal-border font-bold">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ALL INDUSTRIES</SelectItem>
                  <SelectItem value="Technology">TECHNOLOGY</SelectItem>
                  <SelectItem value="Manufacturing">MANUFACTURING</SelectItem>
                  <SelectItem value="Retail">RETAIL</SelectItem>
                  <SelectItem value="Energy">ENERGY</SelectItem>
                  <SelectItem value="Transportation">TRANSPORTATION</SelectItem>
                  <SelectItem value="Healthcare">HEALTHCARE</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-black uppercase text-steel mb-2">
                RISK LEVEL
              </label>
              <Select value={selectedRisk} onValueChange={setSelectedRisk}>
                <SelectTrigger className="brutal-border font-bold">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">ALL RISKS</SelectItem>
                  <SelectItem value="low">LOW RISK</SelectItem>
                  <SelectItem value="medium">MEDIUM RISK</SelectItem>
                  <SelectItem value="high">HIGH RISK</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-black uppercase text-steel mb-2">
                SORT BY
              </label>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="brutal-border font-bold">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="return">HIGHEST RETURN</SelectItem>
                  <SelectItem value="amount">LARGEST AMOUNT</SelectItem>
                  <SelectItem value="due">SHORTEST TERM</SelectItem>
                  <SelectItem value="rate">HIGHEST RATE</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button variant="brutal" className="uppercase">
              <ListFilter className="w-4 h-4 mr-2" />
              FILTER
            </Button>
          </div>
        </div>

        {/* Invoice Listings */}
        <div className="space-y-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-black uppercase">
              AVAILABLE INVOICES ({filteredInvoices.length})
            </h2>
            <Button 
              variant="brutal-outline" 
              size="sm" 
              className="uppercase"
              onClick={handleRefresh}
              disabled={refreshing}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              REFRESH
            </Button>
          </div>
          
          {cacheLoading ? (
            <div className="brutal-card p-12 bg-card text-center">
              <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-electric-blue" />
              <div className="font-black text-xl uppercase">LOADING INVOICES FROM BLOCKCHAIN</div>
              <div className="text-steel font-medium mt-2">Fetching data from smart contracts...</div>
            </div>
          ) : filteredInvoices.length === 0 ? (
            <div className="brutal-card p-12 bg-card text-center">
              <Network className="w-16 h-16 mx-auto mb-4 text-steel" />
              <div className="font-black text-xl uppercase mb-2">NO INVOICES FOUND</div>
              <div className="text-steel font-medium mb-4">
                {invoices.length === 0 
                  ? "No invoices are currently listed on the marketplace"
                  : "Try adjusting your filters or search criteria"}
              </div>
              <Button variant="brutal" onClick={handleRefresh}>
                <RefreshCw className="w-4 h-4 mr-2" />
                REFRESH
              </Button>
            </div>
          ) : (
            filteredInvoices.map((invoice) => (
            <div key={invoice.id} className="brutal-card p-6 bg-card hover:translate-x-1 hover:translate-y-1 transition-transform">
              <div className="grid lg:grid-cols-6 gap-6 items-start">
                {/* Company Info */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Building2 className="w-5 h-5 text-steel" />
                    <div className="font-black text-lg">{invoice.company}</div>
                  </div>
                  <div className="font-bold text-steel mb-1">{invoice.invoiceNumber}</div>
                  <div className="text-sm text-steel font-medium">
                    {invoice.industry}
                  </div>
                  <div className="text-xs text-steel mt-2">
                    {invoice.description}
                  </div>
                </div>
                
                {/* Investment Amount */}
                <div className="text-center">
                  <div className="text-2xl font-black text-primary">
                    ${invoice.investmentAmount.toLocaleString()}
                  </div>
                  <div className="text-sm font-bold text-steel uppercase mb-1">
                    INVESTMENT
                  </div>
                  <div className="text-xs text-steel">
                    ${invoice.originalAmount.toLocaleString()} original
                  </div>
                </div>
                
                {/* Expected Return */}
                <div className="text-center">
                  <div className="text-2xl font-black neon-accent">
                    ${invoice.expectedReturn.toLocaleString()}
                  </div>
                  <div className="text-sm font-bold text-steel uppercase mb-1">
                    RETURN
                  </div>
                  <div className="text-xs text-steel">
                    ${(invoice.expectedReturn - invoice.investmentAmount).toLocaleString()} profit
                  </div>
                </div>
                
                {/* Discount Rate */}
                <div className="text-center">
                  <div className="text-2xl font-black text-hot-pink">
                    {invoice.discountRate}%
                  </div>
                  <div className="text-sm font-bold text-steel uppercase mb-1">
                    DISCOUNT
                  </div>
                  <div className="text-xs text-steel">
                    Annual rate
                  </div>
                </div>
                
                {/* Due Date & Ratings */}
                <div>
                  <div className="flex items-center gap-1 mb-2">
                    <Calendar className="w-4 h-4 text-steel" />
                    <div className="font-bold text-foreground">{invoice.dueDate}</div>
                  </div>
                  <div className="text-sm font-medium text-steel mb-3">
                    {invoice.daysUntilDue} days to maturity
                  </div>
                  
                  <div className="space-y-2">
                    <Badge className={`brutal-border font-black ${getRatingColor(invoice.creditRating)}`}>
                      {invoice.creditRating} RATED
                    </Badge>
                    <Badge className={`brutal-border font-black ${getRiskColor(invoice.riskLevel)}`}>
                      {invoice.riskLevel.toUpperCase()} RISK
                    </Badge>
                  </div>
                </div>
                
                {/* Action Button */}
                <div className="flex flex-col gap-3">
                  {invoice.approvalStatus ? (
                    <>
                      <Button 
                        variant="brutal" 
                        size="lg" 
                        className="uppercase w-full"
                        onClick={() => handleInvest(invoice)}
                      >
                        <DollarSign className="w-4 h-4 mr-2" />
                        INVEST NOW
                      </Button>
                      
                      <div className="text-center">
                        <div className="text-sm font-black text-neon-green">
                          {((invoice.expectedReturn - invoice.investmentAmount) / invoice.investmentAmount * 100).toFixed(1)}% ROI
                        </div>
                        <div className="text-xs text-steel">
                          Return on investment
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="brutal-card p-4 bg-electric-yellow text-center">
                      <AlertCircle className="w-8 h-8 mx-auto mb-2 text-foreground" />
                      <div className="font-black text-foreground text-sm">
                        NOT AVAILABLE
                      </div>
                      <div className="text-xs text-foreground font-medium mt-1">
                        Seller hasn't approved marketplace
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
            ))
          )}
        </div>

      </div>

      {/* Investment Modal */}
      <Dialog open={isInvestModalOpen} onOpenChange={setIsInvestModalOpen}>
        <DialogContent className="brutal-card bg-card border-foreground max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black uppercase">
              INVEST IN {selectedInvoice?.invoiceNumber}
            </DialogTitle>
            <DialogDescription className="text-steel font-medium">
              {investmentStep === 'method' && `Choose your payment method for $${selectedInvoice?.investmentAmount.toLocaleString()}`}
              {investmentStep === 'calculating' && 'Calculating USDC amount...'}
              {investmentStep === 'approving' && 'Approve USDC spending'}
              {investmentStep === 'purchasing' && 'Complete your purchase'}
              {investmentStep === 'success' && 'Purchase successful!'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Method Selection */}
            {investmentStep === 'method' && (
              <>
                <Button
                  variant="brutal"
                  size="lg"
                  className="w-full uppercase"
                  onClick={() => handlePaymentOption('stablecoin')}
                  disabled={isProcessing}
                >
                  <Coins className="w-5 h-5 mr-2" />
                  PAY WITH STABLE COIN
                </Button>
                
                <Button
                  variant="brutal-outline"
                  size="lg"
                  className="w-full uppercase"
                  onClick={() => handlePaymentOption('swift')}
                  disabled={isProcessing}
                >
                  <Network className="w-5 h-5 mr-2" />
                  PAY ON SWIFT NETWORK
                </Button>
                
                <Button
                  variant="ghost"
                  size="lg"
                  className="w-full uppercase font-black"
                  onClick={closeModal}
                >
                  <X className="w-5 h-5 mr-2" />
                  CANCEL
                </Button>
              </>
            )}

            {/* Calculating */}
            {investmentStep === 'calculating' && (
              <div className="brutal-card p-8 bg-background text-center">
                <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-electric-blue" />
                <div className="font-black text-lg uppercase">CALCULATING USDC AMOUNT</div>
                <div className="text-steel font-medium mt-2">Getting quote from smart contract...</div>
              </div>
            )}

            {/* Approval Step */}
            {investmentStep === 'approving' && (
              <>
                {/* Trust Status Card - Exact replica from InvoiceUploadStep3 */}
                <Card className="p-6">
                  <h4 className="text-lg font-black uppercase mb-4 flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    Registry Status
                  </h4>
                  
                  {!partyStatus && (
                    <div className="flex items-center gap-3">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span className="text-sm">Checking registry status...</span>
                    </div>
                  )}
                  
                  {partyStatus?.isTrusted && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Status:</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Trusted
                        </Badge>
                      </div>
                      {partyStatus.party && (
                        <div className="flex items-center justify-between">
                          <span className="font-medium">LEI:</span>
                          <span className="font-mono text-sm">{partyStatus.party.lei}</span>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {partyStatus?.isRegistered && !partyStatus.isTrusted && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Status:</span>
                        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                          Registered - Pending Verification
                        </Badge>
                      </div>
                      {partyStatus.party && (
                        <div className="flex items-center justify-between">
                          <span className="font-medium">LEI:</span>
                          <span className="font-mono text-sm">{partyStatus.party.lei}</span>
                        </div>
                      )}
                      <p className="text-sm text-steel">
                        Your registration is pending verification by the oracle. Please wait for approval.
                      </p>
                    </div>
                  )}
                  
                  {!partyStatus?.isRegistered && partyStatus && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Status:</span>
                        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                          Not Registered
                        </Badge>
                      </div>
                      <p className="text-sm text-steel">
                        You must register in the PartyRegistry with a valid LEI to invest in invoices.
                      </p>
                      
                      <Dialog open={isRegisterDialogOpen} onOpenChange={setIsRegisterDialogOpen}>
                        <DialogTrigger asChild>
                          <Button variant="brutal" size="sm" className="w-full uppercase">
                            <UserPlus className="mr-2 w-4 h-4" />
                            Register with LEI
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-md">
                          <DialogHeader>
                            <DialogTitle className="font-black text-xl">REGISTER WITH LEI</DialogTitle>
                          </DialogHeader>
                          
                          <div className="space-y-4">
                            <div className="brutal-card p-4 bg-electric-yellow">
                              <p className="text-sm font-bold text-foreground">
                                ⚠️ You need a valid Legal Entity Identifier (LEI) from GLEIF to register.
                              </p>
                            </div>
                            
                            <Form {...form}>
                              <form onSubmit={form.handleSubmit(handleRegister)} className="space-y-4">
                                <FormField
                                  control={form.control}
                                  name="lei"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel className="font-bold uppercase">LEI (20 characters)</FormLabel>
                                      <FormControl>
                                        <Input
                                          {...field}
                                          placeholder="Enter your LEI code"
                                          className="uppercase font-mono"
                                          maxLength={20}
                                        />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={form.control}
                                  name="vlei"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel className="font-bold uppercase">vLEI</FormLabel>
                                      <FormControl>
                                        <Input
                                          {...field}
                                          placeholder="Enter your vLEI"
                                        />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <Button
                                  type="submit"
                                  variant="brutal"
                                  className="w-full uppercase"
                                  disabled={isRegistering}
                                >
                                  {isRegistering ? (
                                    <>
                                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                      REGISTERING...
                                    </>
                                  ) : (
                                    'REGISTER'
                                  )}
                                </Button>
                              </form>
                            </Form>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  )}
                </Card>
                
                <div className="brutal-card p-6 bg-electric-blue">
                  <div className="text-center">
                    <div className="text-4xl font-black text-background mb-2">
                      {calculatedUSDC} USDC
                    </div>
                    <div className="text-sm font-bold text-background uppercase">
                      REQUIRED (INCLUDES 1% BUFFER)
                    </div>
                  </div>
                </div>

                <div className="brutal-card p-4 bg-background">
                  <div className="flex gap-2 text-sm text-steel font-medium">
                    <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <div>
                      This allows the marketplace contract to transfer USDC from your wallet. The 1% buffer protects against price fluctuations.
                    </div>
                  </div>
                </div>

                <Button
                  variant="brutal"
                  size="lg"
                  className="w-full uppercase"
                  onClick={handleApprove}
                  disabled={isProcessing || !partyStatus?.isTrusted}
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      APPROVING...
                    </>
                  ) : !partyStatus?.isTrusted ? (
                    <>
                      <AlertCircle className="w-5 h-5 mr-2" />
                      REGISTER FIRST
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-5 h-5 mr-2" />
                      APPROVE USDC
                    </>
                  )}
                </Button>

                <Button
                  variant="ghost"
                  size="lg"
                  className="w-full uppercase font-black"
                  onClick={closeModal}
                  disabled={isProcessing}
                >
                  <X className="w-5 h-5 mr-2" />
                  CANCEL
                </Button>
              </>
            )}

            {/* Purchase Step */}
            {investmentStep === 'purchasing' && (
              <>
                <div className="brutal-card p-6 bg-neon-green">
                  <div className="text-center">
                    <CheckCircle2 className="w-12 h-12 mx-auto mb-2 text-foreground" />
                    <div className="text-2xl font-black text-foreground mb-2">
                      APPROVED!
                    </div>
                    <div className="text-sm font-bold text-foreground uppercase">
                      READY TO PURCHASE
                    </div>
                  </div>
                </div>

                <div className="brutal-card p-4 bg-background">
                  <div className="flex gap-2 text-sm text-steel font-medium">
                    <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <div>
                      This will transfer USDC from your wallet and transfer the invoice NFT to you.
                    </div>
                  </div>
                </div>

                <Button
                  variant="brutal"
                  size="lg"
                  className="w-full uppercase"
                  onClick={handleCompletePurchase}
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      PURCHASING...
                    </>
                  ) : (
                    <>
                      <DollarSign className="w-5 h-5 mr-2" />
                      COMPLETE PURCHASE
                    </>
                  )}
                </Button>

                <Button
                  variant="ghost"
                  size="lg"
                  className="w-full uppercase font-black"
                  onClick={closeModal}
                  disabled={isProcessing}
                >
                  <X className="w-5 h-5 mr-2" />
                  CANCEL
                </Button>
              </>
            )}

            {/* Success Step */}
            {investmentStep === 'success' && (
              <>
                <div className="brutal-card p-8 bg-neon-green text-center">
                  <CheckCircle2 className="w-16 h-16 mx-auto mb-4 text-foreground" />
                  <div className="text-3xl font-black text-foreground mb-2">
                    PURCHASE SUCCESSFUL!
                  </div>
                  <div className="text-sm font-bold text-foreground">
                    Invoice NFT #{selectedInvoice?.tokenId} is now yours
                  </div>
                </div>

                <div className="brutal-card p-4 bg-background">
                  <div className="text-xs font-mono text-steel break-all">
                    <div className="font-black uppercase mb-1">Transaction Hash:</div>
                    <a 
                      href={`https://sepolia.etherscan.io/tx/${transactionHash}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-electric-blue hover:underline"
                    >
                      {transactionHash}
                    </a>
                  </div>
                </div>

                <Button
                  variant="brutal"
                  size="lg"
                  className="w-full uppercase"
                  onClick={() => navigate('/investor')}
                >
                  VIEW IN INVESTOR DASHBOARD
                </Button>

                <Button
                  variant="ghost"
                  size="lg"
                  className="w-full uppercase font-black"
                  onClick={closeModal}
                >
                  CLOSE
                </Button>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <WalletConnectDialog
        isOpen={showWalletDialog}
        onClose={() => setShowWalletDialog(false)}
        title="Connect Your Wallet to Invest"
        description="You need to connect your wallet to purchase invoices and make investments"
      />
    </div>
  );
};

export default Market;