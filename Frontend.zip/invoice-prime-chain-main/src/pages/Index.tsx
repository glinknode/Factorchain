import Hero from "@/components/Hero";
import FactoringVisual from "@/components/FactoringVisual";
import BlockchainTracker from "@/components/BlockchainTracker";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Hero />
      <FactoringVisual />
      <BlockchainTracker />
    </div>
  );
};

export default Index;
